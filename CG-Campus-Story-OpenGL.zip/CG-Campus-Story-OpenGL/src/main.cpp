#include <GL/glut.h>
#include <iostream>
#include <cmath>
#include <cstdlib>
#include <cstdio>
#include <ctime>
#include <math.h>

#ifdef _WIN32
#include <windows.h>
#endif

using namespace std;


// PROJECT SCENE CONTROL
int scene = 1;
bool waitingForNext = false;
void displayMain();
void keyboardMain(unsigned char key, int x, int y);
void timerMain(int value);

namespace Entrance {

// Internal scene control for this namespace:
// 0 = building view (student walks toward entrance)
// 1 = door-opening / zoom / corridor-glimpse view (student enters)
int scene = 0;

void init()
{
    glClearColor(0.85, 0.85, 0.87, 1);

    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();

    gluOrtho2D(0, 100, 0, 75);
}


//SKY
void sky()
{
    glColor3f(0.55f, 0.78f, 0.95f);

    glBegin(GL_QUADS);
        glVertex2f(0, 54);
        glVertex2f(100, 54);
        glVertex2f(100, 75);
        glVertex2f(0, 75);
    glEnd();
}


// BUILDING
void building()
{
    glColor3f(0.78f, 0.78f, 0.75f);

    glBegin(GL_QUADS);

        glVertex2f(10, 15);
        glVertex2f(90, 15);
        glVertex2f(90, 65);
        glVertex2f(10, 65);

    glEnd();
}


//BRICK LINES
void brickLines()
{
    glColor3f(0.55f, 0.55f, 0.52f);

    glBegin(GL_LINES);

        glVertex2f(10, 25);
        glVertex2f(90, 25);

        glVertex2f(10, 35);
        glVertex2f(90, 35);

        glVertex2f(10, 45);
        glVertex2f(90, 45);

        glVertex2f(10, 55);
        glVertex2f(90, 55);


        glVertex2f(20, 15);
        glVertex2f(20, 25);

        glVertex2f(40, 15);
        glVertex2f(40, 25);

        glVertex2f(60, 15);
        glVertex2f(60, 25);

        glVertex2f(80, 15);
        glVertex2f(80, 25);


        glVertex2f(15, 25);
        glVertex2f(15, 35);

        glVertex2f(30, 25);
        glVertex2f(30, 35);

        glVertex2f(50, 25);
        glVertex2f(50, 35);

        glVertex2f(70, 25);
        glVertex2f(70, 35);

        glVertex2f(85, 25);
        glVertex2f(85, 35);


        glVertex2f(20, 35);
        glVertex2f(20, 45);

        glVertex2f(40, 35);
        glVertex2f(40, 45);

        glVertex2f(60, 35);
        glVertex2f(60, 45);

        glVertex2f(80, 35);
        glVertex2f(80, 45);


        glVertex2f(15, 45);
        glVertex2f(15, 55);

        glVertex2f(30, 45);
        glVertex2f(30, 55);

        glVertex2f(50, 45);
        glVertex2f(50, 55);

        glVertex2f(70, 45);
        glVertex2f(70, 55);

        glVertex2f(85, 45);
        glVertex2f(85, 55);


        glVertex2f(20, 55);
        glVertex2f(20, 65);

        glVertex2f(40, 55);
        glVertex2f(40, 65);

        glVertex2f(60, 55);
        glVertex2f(60, 65);

        glVertex2f(80, 55);
        glVertex2f(80, 65);

    glEnd();
}


// CENTRAL GLASS
void glassBuilding()
{
    glColor3f(0.30f, 0.42f, 0.45f);

    glBegin(GL_QUADS);

        glVertex2f(38, 15);
        glVertex2f(62, 15);
        glVertex2f(62, 68);
        glVertex2f(38, 68);

    glEnd();


    glColor3f(0.65f, 0.75f, 0.77f);

    glBegin(GL_QUADS);

        glVertex2f(40, 17);
        glVertex2f(45, 17);
        glVertex2f(45, 66);
        glVertex2f(40, 66);

    glEnd();
}


// GLASS FRAME
void glassFrame()
{
    glColor3f(0.15f, 0.15f, 0.15f);

    glBegin(GL_LINES);

        glVertex2f(46, 15);
        glVertex2f(46, 68);

        glVertex2f(54, 15);
        glVertex2f(54, 68);

        glVertex2f(38, 25);
        glVertex2f(62, 25);

        glVertex2f(38, 35);
        glVertex2f(62, 35);

        glVertex2f(38, 45);
        glVertex2f(62, 45);

        glVertex2f(38, 55);
        glVertex2f(62, 55);

    glEnd();
}


// LEFT WINDOWS
void leftWindows()
{
    glColor3f(0.65f, 0.72f, 0.73f);

    glBegin(GL_QUADS);

        glVertex2f(16, 48);
        glVertex2f(30, 48);
        glVertex2f(30, 58);
        glVertex2f(16, 58);

        glVertex2f(16, 34);
        glVertex2f(30, 34);
        glVertex2f(30, 44);
        glVertex2f(16, 44);

        glVertex2f(16, 20);
        glVertex2f(30, 20);
        glVertex2f(30, 30);
        glVertex2f(16, 30);

    glEnd();


    glColor3f(0.30f, 0.30f, 0.30f);

    glBegin(GL_LINES);

        glVertex2f(16,48);
        glVertex2f(30,48);

        glVertex2f(30,48);
        glVertex2f(30,58);

        glVertex2f(30,58);
        glVertex2f(16,58);

        glVertex2f(16,58);
        glVertex2f(16,48);

        glVertex2f(23,48);
        glVertex2f(23,58);

        glVertex2f(16,53);
        glVertex2f(30,53);


        glVertex2f(16,34);
        glVertex2f(30,34);

        glVertex2f(30,34);
        glVertex2f(30,44);

        glVertex2f(30,44);
        glVertex2f(16,44);

        glVertex2f(16,44);
        glVertex2f(16,34);

        glVertex2f(23,34);
        glVertex2f(23,44);

        glVertex2f(16,39);
        glVertex2f(30,39);


        glVertex2f(16,20);
        glVertex2f(30,20);

        glVertex2f(30,20);
        glVertex2f(30,30);

        glVertex2f(30,30);
        glVertex2f(16,30);

        glVertex2f(16,30);
        glVertex2f(16,20);

        glVertex2f(23,20);
        glVertex2f(23,30);

        glVertex2f(16,25);
        glVertex2f(30,25);

    glEnd();
}


//RIGHT WINDOWS
void rightWindows()
{
    glColor3f(0.65f, 0.72f, 0.73f);

    glBegin(GL_QUADS);

        glVertex2f(70,48);
        glVertex2f(84,48);
        glVertex2f(84,58);
        glVertex2f(70,58);

        glVertex2f(70,34);
        glVertex2f(84,34);
        glVertex2f(84,44);
        glVertex2f(70,44);

        glVertex2f(70,20);
        glVertex2f(84,20);
        glVertex2f(84,30);
        glVertex2f(70,30);

    glEnd();


    glColor3f(0.30f, 0.30f, 0.30f);

    glBegin(GL_LINES);

        glVertex2f(70,48);
        glVertex2f(84,48);

        glVertex2f(84,48);
        glVertex2f(84,58);

        glVertex2f(84,58);
        glVertex2f(70,58);

        glVertex2f(70,58);
        glVertex2f(70,48);

        glVertex2f(77,48);
        glVertex2f(77,58);

        glVertex2f(70,53);
        glVertex2f(84,53);


        glVertex2f(70,34);
        glVertex2f(84,34);

        glVertex2f(84,34);
        glVertex2f(84,44);

        glVertex2f(84,44);
        glVertex2f(70,44);

        glVertex2f(70,44);
        glVertex2f(70,34);

        glVertex2f(77,34);
        glVertex2f(77,44);

        glVertex2f(70,39);
        glVertex2f(84,39);


        glVertex2f(70,20);
        glVertex2f(84,20);

        glVertex2f(84,20);
        glVertex2f(84,30);

        glVertex2f(84,30);
        glVertex2f(70,30);

        glVertex2f(70,30);
        glVertex2f(70,20);

        glVertex2f(77,20);
        glVertex2f(77,30);

        glVertex2f(70,25);
        glVertex2f(84,25);

    glEnd();
}


// ENTRANCE
void entrance()
{
    glColor3f(0.15f, 0.17f, 0.18f);

    glBegin(GL_QUADS);

        glVertex2f(43,15);
        glVertex2f(57,15);
        glVertex2f(57,27);
        glVertex2f(43,27);

    glEnd();


    glColor3f(0.45f, 0.60f, 0.63f);

    glBegin(GL_QUADS);

        glVertex2f(44,15);
        glVertex2f(49,15);
        glVertex2f(49,26);
        glVertex2f(44,26);

        glVertex2f(51,15);
        glVertex2f(56,15);
        glVertex2f(56,26);
        glVertex2f(51,26);

    glEnd();
}


// RED AWNING
void redAwning()
{
    glColor3f(0.65f, 0.08f, 0.05f);

    glBegin(GL_QUADS);

        glVertex2f(32,27);
        glVertex2f(68,27);
        glVertex2f(68,30);
        glVertex2f(32,30);

    glEnd();
}


// BOOKS & BEYOND
void booksBeyond()
{
    glColor3f(0.55f, 0.32f, 0.18f);

    glBegin(GL_QUADS);

        glVertex2f(15,15);
        glVertex2f(38,15);
        glVertex2f(38,30);
        glVertex2f(15,30);

    glEnd();


    glColor3f(0.40f, 0.60f, 0.63f);

    glBegin(GL_QUADS);

        glVertex2f(17,16);
        glVertex2f(36,16);
        glVertex2f(36,27);
        glVertex2f(17,27);

    glEnd();


    glColor3f(0.20f, 0.20f, 0.20f);

    glBegin(GL_LINES);

        glVertex2f(17,16);
        glVertex2f(36,16);

        glVertex2f(36,16);
        glVertex2f(36,27);

        glVertex2f(36,27);
        glVertex2f(17,27);

        glVertex2f(17,27);
        glVertex2f(17,16);

        glVertex2f(26.5f,16);
        glVertex2f(26.5f,27);

    glEnd();


    glColor3f(0.20f, 0.20f, 0.20f);

    glBegin(GL_QUADS);

        glVertex2f(14,28);
        glVertex2f(39,28);
        glVertex2f(39,32);
        glVertex2f(14,32);

    glEnd();
}


// WALKWAY
void walkway()
{
    glColor3f(0.60f, 0.60f, 0.58f);

    glBegin(GL_QUADS);

        glVertex2f(34,0);
        glVertex2f(66,0);
        glVertex2f(58,15);
        glVertex2f(42,15);

    glEnd();


    glColor3f(0.45f, 0.45f, 0.43f);

    glBegin(GL_LINES);

        glVertex2f(34,0);
        glVertex2f(42,15);

        glVertex2f(66,0);
        glVertex2f(58,15);

    glEnd();
}


// GROUND
void ground()
{
    glColor3f(0.35f, 0.35f, 0.35f);

    glBegin(GL_QUADS);

        glVertex2f(0,0);
        glVertex2f(100,0);
        glVertex2f(100,7);
        glVertex2f(0,7);

    glEnd();
}


// LEFT TREE
void leftTree()
{
    glColor3f(0.45f, 0.25f, 0.10f);

    glBegin(GL_QUADS);

        glVertex2f(5,8);
        glVertex2f(8,8);
        glVertex2f(8,28);
        glVertex2f(5,28);

    glEnd();


    glColor3f(0.05f, 0.45f, 0.10f);

    glBegin(GL_TRIANGLES);

        glVertex2f(6.5f,43);
        glVertex2f(0,25);
        glVertex2f(13,25);

        glVertex2f(6.5f,36);
        glVertex2f(0,18);
        glVertex2f(14,18);

    glEnd();
}


// RIGHT TREE
void rightTree()
{
    glColor3f(0.45f, 0.25f, 0.10f);

    glBegin(GL_QUADS);

        glVertex2f(92,8);
        glVertex2f(95,8);
        glVertex2f(95,29);
        glVertex2f(92,29);

    glEnd();


    glColor3f(0.05f, 0.45f, 0.10f);

    glBegin(GL_TRIANGLES);

        glVertex2f(93.5f,44);
        glVertex2f(87,26);
        glVertex2f(100,26);

        glVertex2f(93.5f,37);
        glVertex2f(86,19);
        glVertex2f(100,19);

    glEnd();
}


// STUDENT MOVEMENT
float student1Y = 2.0f;

float speed = 0.05f;
int walkStep = 0;

bool walking = false;
bool doorOpening = false;
bool entering = false;

float zoom = 1.0f;


// STUDENT 1
void student1()
{
    glPushMatrix();

    glTranslatef(50, student1Y, 0);

    glColor3f(0.72f, 0.48f, 0.32f);

    glBegin(GL_POLYGON);

        glVertex2f(-1.5f, 6.0f);
        glVertex2f(-1.1f, 6.7f);
        glVertex2f(-0.4f, 7.1f);
        glVertex2f(0.4f, 7.1f);
        glVertex2f(1.1f, 6.7f);
        glVertex2f(1.5f, 6.0f);
        glVertex2f(1.1f, 5.3f);
        glVertex2f(0.4f, 5.0f);
        glVertex2f(-0.4f, 5.0f);
        glVertex2f(-1.1f, 5.3f);

    glEnd();

    glColor3f(0.08f, 0.04f, 0.02f);

    glBegin(GL_POLYGON);

        glVertex2f(-1.4f, 6.2f);
        glVertex2f(-1.0f, 6.9f);
        glVertex2f(-0.3f, 7.2f);
        glVertex2f(0.5f, 7.1f);
        glVertex2f(1.3f, 6.4f);
        glVertex2f(0.9f, 6.5f);
        glVertex2f(-0.8f, 6.5f);

    glEnd();

    glColor3f(0.05f, 0.25f, 0.45f);

    glBegin(GL_QUADS);

        glVertex2f(-1.4f, 4.8f);
        glVertex2f(1.4f, 4.8f);
        glVertex2f(1.2f, 1.0f);
        glVertex2f(-1.2f, 1.0f);

    glEnd();

    glColor3f(0.72f, 0.48f, 0.32f);

    glBegin(GL_LINES);

        glVertex2f(-1.2f, 4.2f);
        glVertex2f(-2.0f, 2.5f);

        glVertex2f(1.2f, 4.2f);

        if (walkStep < 5)
            glVertex2f(2.0f, 2.5f);
        else
            glVertex2f(1.5f, 2.0f);

    glEnd();

    glColor3f(0.08f, 0.08f, 0.10f);

    glBegin(GL_QUADS);

        if (walkStep < 5)
        {
            glVertex2f(-1.0f, 1.0f);
            glVertex2f(-0.1f, 1.0f);
            glVertex2f(-0.8f, -1.8f);
            glVertex2f(-1.5f, -1.8f);

            glVertex2f(0.1f, 1.0f);
            glVertex2f(1.0f, 1.0f);
            glVertex2f(1.6f, -1.5f);
            glVertex2f(0.8f, -1.5f);
        }
        else
        {
            glVertex2f(-1.0f, 1.0f);
            glVertex2f(-0.1f, 1.0f);
            glVertex2f(-0.3f, -1.6f);
            glVertex2f(-1.0f, -1.6f);

            glVertex2f(0.1f, 1.0f);
            glVertex2f(1.0f, 1.0f);
            glVertex2f(0.3f, -1.8f);
            glVertex2f(-0.4f, -1.8f);
        }

    glEnd();

    glPopMatrix();
}


// SMALL CORRIDOR GLIMPSE INSIDE THE SAME ENTRANCE
void corridorGlimpse(float r)
{
    if(r <= 0.0f)
        return;

    glColor3f(0.18f, 0.20f, 0.20f);

    glBegin(GL_QUADS);

        glVertex2f(44.0f, 15.0f);
        glVertex2f(56.0f, 15.0f);
        glVertex2f(56.0f, 26.0f);
        glVertex2f(44.0f, 26.0f);

    glEnd();

    glColor3f(0.45f, 0.45f, 0.45f);

    glBegin(GL_QUADS);

        glVertex2f(44.0f, 15.0f);
        glVertex2f(56.0f, 15.0f);
        glVertex2f(53.0f, 19.0f);
        glVertex2f(47.0f, 19.0f);

    glEnd();

    if(r > 0.35f)
    {
        glColor3f(1.0f, 1.0f, 0.75f);

        glBegin(GL_QUADS);

            glVertex2f(47.0f, 24.0f);
            glVertex2f(53.0f, 24.0f);
            glVertex2f(52.0f, 23.0f);
            glVertex2f(48.0f, 23.0f);

        glEnd();
    }

    if(r > 0.55f)
    {
        glColor3f(0.40f, 0.20f, 0.07f);

        glBegin(GL_QUADS);

            glVertex2f(47.0f, 18.0f);
            glVertex2f(53.0f, 18.0f);
            glVertex2f(53.0f, 19.0f);
            glVertex2f(47.0f, 19.0f);

        glEnd();
    }
}


// ENTRANCE DOORS
void openingEntranceDoors(float r)
{
    float leftX = 44.0f - 1.0f * r;
    float rightX = 51.0f + 1.0f * r;

    glColor3f(0.15f, 0.17f, 0.18f);

    glBegin(GL_QUADS);

        glVertex2f(43.0f, 15.0f);
        glVertex2f(leftX, 15.0f);
        glVertex2f(leftX, 27.0f);
        glVertex2f(43.0f, 27.0f);

    glEnd();

    glBegin(GL_QUADS);

        glVertex2f(rightX, 15.0f);
        glVertex2f(57.0f, 15.0f);
        glVertex2f(57.0f, 27.0f);
        glVertex2f(rightX, 27.0f);

    glEnd();

    glColor3f(0.45f, 0.60f, 0.63f);

    glBegin(GL_QUADS);

        glVertex2f(44.0f, 15.0f);
        glVertex2f(leftX, 15.0f);
        glVertex2f(leftX, 26.0f);
        glVertex2f(44.0f, 26.0f);

    glEnd();

    glBegin(GL_QUADS);

        glVertex2f(rightX, 15.0f);
        glVertex2f(56.0f, 15.0f);
        glVertex2f(56.0f, 26.0f);
        glVertex2f(rightX, 26.0f);

    glEnd();
}


// FACE SCAN
void faceScan()
{
    glColor3f(0.12f, 0.12f, 0.12f);

    glBegin(GL_QUADS);

        glVertex2f(52.0f, 18.5f);
        glVertex2f(55.0f, 18.5f);
        glVertex2f(55.0f, 22.0f);
        glVertex2f(52.0f, 22.0f);

    glEnd();

    glColor3f(0.20f, 0.70f, 0.70f);

    glBegin(GL_LINE_LOOP);

        glVertex2f(52.4f, 19.0f);
        glVertex2f(54.6f, 19.0f);
        glVertex2f(54.6f, 21.5f);
        glVertex2f(52.4f, 21.5f);

    glEnd();

    glColor3f(0.72f, 0.48f, 0.32f);

    glBegin(GL_POLYGON);

        glVertex2f(53.0f, 19.7f);
        glVertex2f(53.3f, 19.4f);
        glVertex2f(53.8f, 19.4f);
        glVertex2f(54.1f, 19.7f);
        glVertex2f(54.1f, 20.7f);
        glVertex2f(53.8f, 21.0f);
        glVertex2f(53.3f, 21.0f);
        glVertex2f(53.0f, 20.7f);

    glEnd();

    if(student1Y >= 13.8f && !walking)
    {
        glColor3f(0.30f, 1.0f, 0.30f);

        glBegin(GL_LINES);

            glVertex2f(52.5f, 20.2f);
            glVertex2f(54.5f, 20.2f);

        glEnd();
    }
}


// ================= ANIMATION =================
// NOTE: the self-rescheduling glutTimerFunc(30, timer, 0) that existed

void timer(int value)
{
    // Student walks toward entrance
    if(scene == 0 && walking)
    {
        student1Y += speed;

        if(student1Y >= 14.0f)
        {
            student1Y = 14.0f;
            walking = false;
            walkStep = 0;
        }
        else
        {
            walkStep++;

            if(walkStep > 9)
                walkStep = 0;
        }
    }

    // Door opening and zoom
    if(scene == 1 && doorOpening)
    {
        zoom += 0.02f;

        if(zoom >= 1.60f)
        {
            zoom = 1.60f;
            doorOpening = false;
            walkStep = 0;
        }
    }

    // Student enters after zoom
    if(scene == 1 && entering)
    {
        student1Y += 0.08f;

        if(student1Y >= 19.0f)
        {
            student1Y = 19.0f;
            entering = false;
            walkStep = 0;
        }
        else
        {
            walkStep++;

            if(walkStep > 9)
                walkStep = 0;
        }
    }
}


// KEYBOARD
void keyboard(unsigned char key, int x, int y)
{
    if(scene == 0)
    {
        // W = student walks toward entrance
        if(key == 'w' || key == 'W')
        {
            if(student1Y < 14.0f)
                walking = true;
        }

        // N = door opening and zoom
        if(key == 'n' || key == 'N')
        {
            if(student1Y >= 14.0f && !walking)
            {
                scene = 1;
                doorOpening = true;
                entering = false;

                // Student stays close to the entrance
                student1Y = 14.0f;

                zoom = 1.0f;
                walkStep = 0;
            }
        }
    }

    else if(scene == 1)
    {
        // W = student enters building
        if(key == 'w' || key == 'W')
        {
            if(zoom >= 1.60f && !doorOpening)
            {
                entering = true;
                walkStep = 0;
            }
        }
    }
}


// DISPLAY 01
void display01()
{
    glClear(GL_COLOR_BUFFER_BIT);

    float t = (zoom - 1.0f) / 0.60f;

    if(t < 0.0f)
        t = 0.0f;

    if(t > 1.0f)
        t = 1.0f;

    float zoomPivotX = 50.0f;
    float zoomPivotY = 21.0f;

    glPushMatrix();

    glTranslatef(zoomPivotX, zoomPivotY, 0);
    glScalef(zoom, zoom, 1);
    glTranslatef(-zoomPivotX, -zoomPivotY, 0);

    sky();
    building();
    brickLines();
    glassBuilding();
    glassFrame();
    leftWindows();
    rightWindows();
    entrance();
    booksBeyond();
    redAwning();
    ground();
    walkway();
    leftTree();
    rightTree();

    // Corridor
    corridorGlimpse(t);

    // Opening doors
    openingEntranceDoors(t);

    // Scan box always visible
    faceScan();

    // Student visible
    student1();

    glPopMatrix();

    glFlush();
}


// DISPLAY 00
void display00()
{
    glClear(GL_COLOR_BUFFER_BIT);

    sky();
    building();
    brickLines();
    glassBuilding();
    glassFrame();
    leftWindows();
    rightWindows();
    entrance();
    booksBeyond();
    redAwning();
    ground();
    walkway();
    leftTree();
    rightTree();

    faceScan();

    // Only one student
    student1();

    glFlush();
}



void display()
{
    if (scene == 0)
        display00();
    else
        display01();
}

} // namespace Entrance

namespace Corridor {

using namespace std;

float humanX = 50;
float humanY = 0;

bool moving = false;

int phase = 1;


float t = 0;

float doorAngle = 0;
bool doorOpening = false;

float handAngle = 0;
int handPhase = 0;

const float REACH_ANGLE = 60.0f;

float human2X = 44.0f;
float human2Y = 2.5f;

bool walking2 = false;
bool human2Visible = true;

float phase2Scale = 1.0f;


// INIT

void init()
{
    glClearColor(0.85, 0.85, 0.87, 1);

    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();

    gluOrtho2D(0, 100, 0, 75);
}


// CORRIDOR

void floor()
{
    glBegin(GL_POLYGON);
    glColor3f(0.72, 0.72, 0.72);

    glVertex2f(0, 0);
    glVertex2f(100, 0);
    glVertex2f(55, 38);
    glVertex2f(45, 38);

    glEnd();
}

void ceiling()
{
    glBegin(GL_POLYGON);
    glColor3f(1, 1, 1);

    glVertex2f(0, 75);
    glVertex2f(100, 75);
    glVertex2f(55, 50);
    glVertex2f(45, 50);

    glEnd();
}

void leftWall()
{
    glBegin(GL_POLYGON);
    glColor3f(0.95, 0.95, 0.96);

    glVertex2f(0, 0);
    glVertex2f(45, 38);
    glVertex2f(45, 50);
    glVertex2f(0, 75);

    glEnd();
}

void rightWall()
{
    glBegin(GL_POLYGON);
    glColor3f(0.95, 0.95, 0.96);

    glVertex2f(100, 0);
    glVertex2f(100, 75);
    glVertex2f(55, 50);
    glVertex2f(55, 38);

    glEnd();
}

void backWall()
{
    glBegin(GL_QUADS);
    glColor3f(0.93, 0.93, 0.94);

    glVertex2f(45, 38);
    glVertex2f(55, 38);
    glVertex2f(55, 50);
    glVertex2f(45, 50);

    glEnd();
}

void leftWallLine()
{
    glBegin(GL_POLYGON);
    glColor3f(0.05, 0.05, 0.05);

    glVertex2f(0, 0);
    glVertex2f(5, 0);
    glVertex2f(47, 38);
    glVertex2f(45, 38);

    glEnd();
}

void rightWallLine()
{
    glBegin(GL_POLYGON);
    glColor3f(0.05, 0.05, 0.05);

    glVertex2f(95, 0);
    glVertex2f(100, 0);
    glVertex2f(55, 38);
    glVertex2f(53, 38);

    glEnd();
}


// DOORS

void leftDoor1()
{
    glBegin(GL_POLYGON);
    glColor3f(0.60, 0.35, 0.12);

    glVertex2f(8, 2.5);
    glVertex2f(21, 14.5);
    glVertex2f(21, 56);
    glVertex2f(8, 63);

    glEnd();
}

void leftDoor1Handle()
{
    glBegin(GL_QUADS);
    glColor3f(0, 0, 0);

    glVertex2f(18.5, 35);
    glVertex2f(20, 35);
    glVertex2f(20, 38);
    glVertex2f(18.5, 38);

    glEnd();
}

void leftDoor2()
{
    glBegin(GL_POLYGON);
    glColor3f(0.60, 0.35, 0.12);

    glVertex2f(30, 22.5);
    glVertex2f(38, 30);
    glVertex2f(38, 49);
    glVertex2f(30, 53);

    glEnd();
}

void leftDoor2Handle()
{
    glBegin(GL_QUADS);
    glColor3f(0, 0, 0);

    glVertex2f(36, 35.5);
    glVertex2f(37.2, 35.5);
    glVertex2f(37.2, 38);
    glVertex2f(36, 38);

    glEnd();
}

void rightDoor1()
{
    glBegin(GL_POLYGON);
    glColor3f(0.60, 0.35, 0.12);

    glVertex2f(79, 14.5);
    glVertex2f(92, 2.8);
    glVertex2f(92, 63);
    glVertex2f(79, 56);

    glEnd();
}

void rightDoor1Handle()
{
    glBegin(GL_QUADS);
    glColor3f(0, 0, 0);

    glVertex2f(80, 35);
    glVertex2f(81.5, 35);
    glVertex2f(81.5, 38);
    glVertex2f(80, 38);

    glEnd();
}

void rightDoor2()
{
    glBegin(GL_POLYGON);
    glColor3f(0.60, 0.35, 0.12);

    glVertex2f(62, 30);
    glVertex2f(70, 22.6);
    glVertex2f(70, 53);
    glVertex2f(62, 49);

    glEnd();
}

void rightDoor2Handle()
{
    glBegin(GL_QUADS);
    glColor3f(0, 0, 0);

    glVertex2f(63, 35);
    glVertex2f(64.2, 35);
    glVertex2f(64.2, 37.5);
    glVertex2f(63, 37.5);

    glEnd();
}


// LIGHTS

void ceilingLight1()
{
    glBegin(GL_QUADS);
    glColor3f(1, 1, 0.75);

    glVertex2f(32, 67);
    glVertex2f(68, 67);
    glVertex2f(62, 62);
    glVertex2f(38, 62);

    glEnd();
}

void ceilingLight2()
{
    glBegin(GL_QUADS);
    glColor3f(1, 1, 0.75);

    glVertex2f(39, 56);
    glVertex2f(61, 56);
    glVertex2f(58, 52);
    glVertex2f(42, 52);

    glEnd();
}


// FIRE HOSE

void fireHose()
{
    glBegin(GL_POLYGON);
    glColor3f(0.9, 0, 0);

    glVertex2f(74, 28);
    glVertex2f(78, 25);
    glVertex2f(78, 37);
    glVertex2f(74, 39);

    glEnd();

    glBegin(GL_POLYGON);
    glColor3f(0.45, 0, 0);

    glVertex2f(75, 30);
    glVertex2f(77, 28.5);
    glVertex2f(77, 36);
    glVertex2f(75, 37);

    glEnd();
}


// BLUE GLASS DOOR

void blueGlassDoor()
{
    glBegin(GL_QUADS);
    glColor3f(0.55, 0.80, 0.90);

    glVertex2f(46, 38);
    glVertex2f(54, 38);
    glVertex2f(54, 49);
    glVertex2f(46, 49);

    glEnd();

    glBegin(GL_LINES);
    glColor3f(0.2, 0.2, 0.2);

    glVertex2f(50, 38);
    glVertex2f(50, 49);

    glEnd();
}


// HUMAN

void human(float red, float green, float blue)
{
    float cx = 0;
    float cy = 20;
    float radius = 2;

    glColor3f(0, 0, 0);

    glBegin(GL_POLYGON);

    for(int i = 0; i < 360; i++)
    {
        float angle = i * 3.1416 / 180;

        float x = cx + radius * cos(angle);
        float y = cy + radius * sin(angle);

        glVertex2f(x, y);
    }

    glEnd();

    glColor3f(red, green, blue);

    glBegin(GL_QUADS);

    glVertex2f(-2.3, 18);
    glVertex2f(2.3, 18);
    glVertex2f(2.3, 9);
    glVertex2f(-2.3, 9);

    glEnd();

    glColor3f(0.8, 0.6, 0.4);

    glBegin(GL_QUADS);

    glVertex2f(-2.3, 17.5);
    glVertex2f(-1.5, 17.2);
    glVertex2f(-4.3, 13);
    glVertex2f(-5, 13.5);

    glEnd();

    glPushMatrix();

    glTranslatef(1.5, 17.2, 0);
    glRotatef(handAngle, 0, 0, 1);

    glColor3f(0.8, 0.6, 0.4);

    glBegin(GL_QUADS);

    glVertex2f(0.8, 0.3);
    glVertex2f(0, 0);
    glVertex2f(2.8, -4.2);
    glVertex2f(3.5, -3.7);

    glEnd();

    glPopMatrix();

    glColor3f(0.1, 0.1, 0.1);

    glBegin(GL_QUADS);

    glVertex2f(-1.6, 9);
    glVertex2f(-0.7, 9);
    glVertex2f(-0.7, 3);
    glVertex2f(-1.6, 3);

    glEnd();

    glBegin(GL_QUADS);

    glVertex2f(0.7, 9);
    glVertex2f(1.6, 9);
    glVertex2f(1.6, 3);
    glVertex2f(0.7, 3);

    glEnd();
}


// PHASE 1

void display1()
{
    glClear(GL_COLOR_BUFFER_BIT);

    float zoomPivotX = 50.0f;
    float zoomPivotY = 44.0f;

    float zoom = 1.0f + 0.6f * t;

    glPushMatrix();

    glTranslatef(zoomPivotX, zoomPivotY, 0);
    glScalef(zoom, zoom, 1);
    glTranslatef(-zoomPivotX, -zoomPivotY, 0);

    floor();
    ceiling();

    leftWall();
    rightWall();
    backWall();

    leftWallLine();
    rightWallLine();

    leftDoor1();
    leftDoor1Handle();

    leftDoor2();
    leftDoor2Handle();

    rightDoor1();
    rightDoor1Handle();

    rightDoor2();
    rightDoor2Handle();

    ceilingLight1();
    ceilingLight2();

    fireHose();

    blueGlassDoor();

    glPushMatrix();

    glTranslatef(humanX, humanY, 0);
    human(0.0, 0.0, 1.0);

    glPopMatrix();

    glPushMatrix();

    glTranslatef(28, 5, 0);
    human(1.0, 0.0, 1.0);

    glPopMatrix();

    glPushMatrix();

    glTranslatef(39, 5, 0);
    human(1.0, 0.0, 0.0);

    glPopMatrix();

    glPopMatrix();

    glFlush();
}


// PHASE 2 HUMAN

void phase2Human()
{
    if(!human2Visible)
        return;

    glPushMatrix();

    glTranslatef(human2X, human2Y, 0);
    glScalef(2.5f, 2.5f, 1);

    human(0.0, 0.0, 1.0);

    glPopMatrix();
}


// INSIDE CLASSROOM

void insideScene()
{
    glColor3f(0.78, 0.80, 0.80);

    glBegin(GL_QUADS);

    glVertex2f(27, 10);
    glVertex2f(73, 10);
    glVertex2f(73, 66);
    glVertex2f(27, 66);

    glEnd();

    glColor3f(0.65, 0.67, 0.67);

    glBegin(GL_QUADS);

    glVertex2f(35, 48);
    glVertex2f(68, 48);
    glVertex2f(68, 60);
    glVertex2f(35, 60);

    glEnd();

    glColor3f(0.1, 0.2, 0.7);

    glBegin(GL_LINE_LOOP);

    glVertex2f(35, 48);
    glVertex2f(68, 48);
    glVertex2f(68, 60);
    glVertex2f(35, 60);

    glEnd();

    glColor3f(0.45, 0.22, 0.08);

    glBegin(GL_QUADS);

    glVertex2f(28, 27);
    glVertex2f(52, 27);
    glVertex2f(52, 30);
    glVertex2f(28, 30);

    glEnd();

    glBegin(GL_QUADS);

    glVertex2f(30, 20);
    glVertex2f(32, 20);
    glVertex2f(32, 27);
    glVertex2f(30, 27);

    glEnd();

    glBegin(GL_QUADS);

    glVertex2f(48, 20);
    glVertex2f(50, 20);
    glVertex2f(50, 27);
    glVertex2f(48, 27);

    glEnd();

    glColor3f(0.45, 0.22, 0.08);

    glBegin(GL_QUADS);

    glVertex2f(53, 25);
    glVertex2f(72, 25);
    glVertex2f(72, 28);
    glVertex2f(53, 28);

    glEnd();
}

// BLUE SIGN

void blueSign()
{
    glColor3f(0.0, 0.3, 1.0);

    glBegin(GL_QUADS);

    glVertex2f(43, 59);
    glVertex2f(57, 59);
    glVertex2f(57, 64);
    glVertex2f(43, 64);

    glEnd();

    glColor3f(1, 1, 1);

    glRasterPos2f(47, 60.5);

    string text = "9302";

    for(int i = 0; i < (int)text.length(); i++)
    {
        glutBitmapCharacter(GLUT_BITMAP_HELVETICA_18, text[i]);
    }
}


// PHASE 2 DOOR

void phase2Door()
{
    insideScene();

    glColor3f(0.25, 0.25, 0.25);

    glBegin(GL_QUADS);
    glVertex2f(25, 8);
    glVertex2f(75, 8);
    glVertex2f(75, 11);
    glVertex2f(25, 11);
    glEnd();

    glBegin(GL_QUADS);
    glVertex2f(25, 65);
    glVertex2f(75, 65);
    glVertex2f(75, 68);
    glVertex2f(25, 68);
    glEnd();

    glBegin(GL_QUADS);
    glVertex2f(25, 8);
    glVertex2f(28, 8);
    glVertex2f(28, 68);
    glVertex2f(25, 68);
    glEnd();

    glBegin(GL_QUADS);
    glVertex2f(72, 8);
    glVertex2f(75, 8);
    glVertex2f(75, 68);
    glVertex2f(72, 68);
    glEnd();


    glPushMatrix();

    glTranslatef(27, 10, 0);

    float openScale = 1.0f - (doorAngle / 90.0f) * 0.75f;

    glScalef(openScale, 1, 1);

    glTranslatef(-27, -10, 0);

    glColor3f(0.60, 0.35, 0.12);

    glBegin(GL_QUADS);

    glVertex2f(27, 10);
    glVertex2f(73, 10);
    glVertex2f(73, 66);
    glVertex2f(27, 66);

    glEnd();

    blueSign();

    glColor3f(0, 0, 0);

    glBegin(GL_QUADS);

    glVertex2f(65, 35);
    glVertex2f(67, 35);
    glVertex2f(67, 38);
    glVertex2f(65, 38);

    glEnd();

    glPopMatrix();
}

// PHASE 2 DISPLAY

void display2()
{
    glClear(GL_COLOR_BUFFER_BIT);

    glColor3f(0.85, 0.85, 0.87);

    glBegin(GL_QUADS);

    glVertex2f(0, 0);
    glVertex2f(100, 0);
    glVertex2f(100, 75);
    glVertex2f(0, 75);

    glEnd();

    glPushMatrix();

    float pivotX = 50.0f;
    float pivotY = 38.0f;

    glTranslatef(pivotX, pivotY, 0);
    glScalef(phase2Scale, phase2Scale, 1);
    glTranslatef(-pivotX, -pivotY, 0);

    phase2Door();
    phase2Human();

    glPopMatrix();

    glFlush();
}


// DISPLAY

void displaymain1()
{
    if(phase == 1)
        display1();
    else
        display2();
}


// KEYBOARD

void keyboard(unsigned char key, int x, int y)
{
    if(phase == 1)
    {
        if(key == 'w' || key == 'W')
            moving = true;
    }
    else if(phase == 2)
    {
        if((key == 'o' || key == 'O') && handPhase == 0)
            handPhase = 1;
    }
}


// TIMER

void timer(int value)
{
    if(phase == 1)
    {
        if(moving)
        {
            humanX += 0.05;
            humanY += 0.125;

            if(humanX >= 60)
            {
                humanX = 60;
                humanY = 30;

                moving = false;
                phase = 2;
            }

            t = humanY / 25.0f;

            glutPostRedisplay();
        }
    }

    else if(phase == 2)
    {
        if(handPhase == 1)
        {
            handAngle += 1.0;

            if(handAngle >= REACH_ANGLE)
            {
                handAngle = REACH_ANGLE;
                handPhase = 2;
                doorOpening = true;
            }

            glutPostRedisplay();
        }

        if(doorOpening)
        {
            if(doorAngle < 90)
            {
                doorAngle += 0.3;
            }
            else
            {
                doorAngle = 90;
                doorOpening = false;
                walking2 = true;
            }

            if(handPhase == 2 && handAngle > 0)
            {
                handAngle -= 0.6;

                if(handAngle <= 0)
                {
                    handAngle = 0;
                    handPhase = 0;
                }
            }

            glutPostRedisplay();
        }

        if(walking2)
        {
            // X-e beshi movement -> "aisle dhore samne hata" feel
            // Y-e kom movement -> "chad er dike urey jawa" look komanor jonno
            human2X += 0.15f;
            human2Y += 0.05f;

            phase2Scale += 0.003f;

            // exit condition ekhon X-bhittik, Y na
            if(human2X >= 65.0f)
            {
                walking2 = false;
                human2Visible = false;
            }

            glutPostRedisplay();
        }
    }
}


// MAIN



}

namespace Classroom {

void init()
{
    glClearColor(0.85, 0.85, 0.87, 1);
    gluOrtho2D(0, 100, 0, 75);
}

// ===================== CEILING =====================

void drawCeiling() //345611
{
    glBegin(GL_QUADS);
    glColor3f(0.82, 0.82, 0.82);
    glVertex2f(0, 54);
    glVertex2f(100, 54);
    glVertex2f(100, 75);
    glVertex2f(0, 75);
    glEnd();
}

void drawCeilingTiles()//345612
{
    glBegin(GL_LINES);
    glColor3f(0.65, 0.65, 0.65);
    glVertex2f(0, 56);
    glVertex2f(100, 56);
    glEnd();

    glBegin(GL_LINES);
    glColor3f(0.65, 0.65, 0.65);
    glVertex2f(0, 61);
    glVertex2f(100, 61);
    glEnd();

    glBegin(GL_LINES);
    glColor3f(0.65, 0.65, 0.65);
    glVertex2f(0, 65);
    glVertex2f(100, 65);
    glEnd();

    glBegin(GL_LINES);
    glColor3f(0.65, 0.65, 0.65);
    glVertex2f(0, 69);
    glVertex2f(100, 69);
    glEnd();

    glBegin(GL_LINES);
    glColor3f(0.65, 0.65, 0.65);
    glVertex2f(0, 74);
    glVertex2f(100, 74);
    glEnd();

    glBegin(GL_LINES);
    glColor3f(0.65, 0.65, 0.65);
    glVertex2f(3, 54);
    glVertex2f(3, 75);
    glEnd();

    glBegin(GL_LINES);
    glColor3f(0.65, 0.65, 0.65);
    glVertex2f(10, 54);
    glVertex2f(10, 75);
    glEnd();

    glBegin(GL_LINES);
    glColor3f(0.65, 0.65, 0.65);
    glVertex2f(17, 54);
    glVertex2f(17, 75);
    glEnd();

    glBegin(GL_LINES);
    glColor3f(0.65, 0.65, 0.65);
    glVertex2f(23, 54);
    glVertex2f(23, 75);
    glEnd();

    glBegin(GL_LINES);
    glColor3f(0.65, 0.65, 0.65);
    glVertex2f(30, 54);
    glVertex2f(30, 75);
    glEnd();

    glBegin(GL_LINES);
    glColor3f(0.65, 0.65, 0.65);
    glVertex2f(37, 54);
    glVertex2f(37, 75);
    glEnd();

    glBegin(GL_LINES);
    glColor3f(0.65, 0.65, 0.65);
    glVertex2f(43, 54);
    glVertex2f(43, 75);
    glEnd();

    glBegin(GL_LINES);
    glColor3f(0.65, 0.65, 0.65);
    glVertex2f(50, 54);
    glVertex2f(50, 75);
    glEnd();

    glBegin(GL_LINES);
    glColor3f(0.65, 0.65, 0.65);
    glVertex2f(57, 54);
    glVertex2f(57, 75);
    glEnd();

    glBegin(GL_LINES);
    glColor3f(0.65, 0.65, 0.65);
    glVertex2f(63, 54);
    glVertex2f(63, 75);
    glEnd();

    glBegin(GL_LINES);
    glColor3f(0.65, 0.65, 0.65);
    glVertex2f(70, 54);
    glVertex2f(70, 75);
    glEnd();

    glBegin(GL_LINES);
    glColor3f(0.65, 0.65, 0.65);
    glVertex2f(77, 54);
    glVertex2f(77, 75);
    glEnd();

    glBegin(GL_LINES);
    glColor3f(0.65, 0.65, 0.65);
    glVertex2f(83, 54);
    glVertex2f(83, 75);
    glEnd();

    glBegin(GL_LINES);
    glColor3f(0.65, 0.65, 0.65);
    glVertex2f(90, 54);
    glVertex2f(90, 75);
    glEnd();

    glBegin(GL_LINES);
    glColor3f(0.65, 0.65, 0.65);
    glVertex2f(97, 54);
    glVertex2f(97, 75);
    glEnd();
}

// ===================== WALLS =====================

void drawBackWall()//345613
{
    glBegin(GL_QUADS);
    glColor3f(0.91, 0.91, 0.89);
    glVertex2f(0, 22);
    glVertex2f(100, 22);
    glVertex2f(100, 54);
    glVertex2f(0, 54);
    glEnd();
}

void drawLeftSideWall()//345614
{
    glBegin(GL_QUADS);
    glColor3f(0.82, 0.82, 0.8);
    glVertex2f(0, 22);
    glVertex2f(7, 22);
    glVertex2f(7, 54);
    glVertex2f(0, 54);
    glEnd();
}

void drawRightSideWall()//345615
{
    glBegin(GL_QUADS);
    glColor3f(0.82, 0.82, 0.8);
    glVertex2f(93, 22);
    glVertex2f(100, 22);
    glVertex2f(100, 54);
    glVertex2f(93, 54);
    glEnd();
}

// FLOOR

void drawFloor()//345616
{
    glBegin(GL_QUADS);
    glColor3f(0.78, 0.78, 0.74);
    glVertex2f(0, 0);
    glVertex2f(100, 0);
    glVertex2f(100, 28);
    glVertex2f(0, 28);
    glEnd();
}

void drawFloorLines()//345617
{
    glBegin(GL_LINES);
    glColor3f(0.65, 0.65, 0.62);
    glVertex2f(0, 7);
    glVertex2f(100, 7);
    glEnd();

    glBegin(GL_LINES);
    glColor3f(0.65, 0.65, 0.62);
    glVertex2f(0, 14);
    glVertex2f(100, 14);
    glEnd();

    glBegin(GL_LINES);
    glColor3f(0.65, 0.65, 0.62);
    glVertex2f(0, 21);
    glVertex2f(100, 21);
    glEnd();
}

// PROJECTOR SCREEN

void drawProjectorScreen()//345618
{
    glBegin(GL_QUADS);
    glColor3f(0.5, 0.52, 0.52);
    glVertex2f(31, 33);
    glVertex2f(69, 33);
    glVertex2f(69, 52);
    glVertex2f(31, 52);
    glEnd();

    glBegin(GL_QUADS);
    glColor3f(0.72, 0.74, 0.74);
    glVertex2f(32, 34);
    glVertex2f(68, 34);
    glVertex2f(68, 51);
    glVertex2f(32, 51);
    glEnd();
}
void drawText(float x, float y, const char* text)
{
    glColor3f(0.05, 0.05, 0.05);

    glRasterPos2f(x, y);

    for (int i = 0; text[i] != '\0'; i++)
    {
        glutBitmapCharacter(GLUT_BITMAP_HELVETICA_10, text[i]);
    }
}

void drawScreenLogo()//345619
{
    glBegin(GL_POLYGON);
    glColor3f(0.08, 0.2, 0.55);
    for (int i = 0; i < 360; i++)
    {
        float angle = i * 3.14159f / 180.0f;
        glVertex2f(50 + 5 * cos(angle), 42.5 + 5.625 * sin(angle));
    }
    glEnd();

    glBegin(GL_POLYGON);
    glColor3f(0.88, 0.88, 0.8);
    for (int i = 0; i < 360; i++)
    {
        float angle = i * 3.14159f / 180.0f;
        glVertex2f(50 + 4 * cos(angle), 42.5 + 4.375 * sin(angle));
    }
    glEnd();

    glBegin(GL_POLYGON);
    glColor3f(0.15, 0.25, 0.6);
    for (int i = 0; i < 360; i++)
    {
        float angle = i * 3.14159f / 180.0f;
        glVertex2f(50 + 1.33 * cos(angle), 42.5 + 1.5 * sin(angle));
    }
    glEnd();
}

// ROOF SUPPORTS

void drawRoofSupports()//345620
{
    glBegin(GL_QUADS);
    glColor3f(0.03, 0.03, 0.03);
    glVertex2f(0, 19);
    glVertex2f(0, 24);
    glVertex2f(24, 54);
    glVertex2f(28, 54);
    glEnd();

    glBegin(GL_QUADS);
    glColor3f(0.03, 0.03, 0.03);
    glVertex2f(100, 15);
    glVertex2f(100, 22);
    glVertex2f(79, 54);
    glVertex2f(75, 54);
    glEnd();
}


void drawCeilingLight1()//345621
{
    glBegin(GL_QUADS);
    glColor3f(0.65, 0.65, 0.65);
    glVertex2f(15, 68);
    glVertex2f(25, 68);
    glVertex2f(25, 70);
    glVertex2f(15, 70);
    glEnd();

    glBegin(GL_QUADS);
    glColor3f(1.0, 1.0, 0.85);
    glVertex2f(16, 68);
    glVertex2f(24, 68);
    glVertex2f(24, 69);
    glVertex2f(16, 69);
    glEnd();
}

void drawCeilingLight2()//345622
{
    glBegin(GL_QUADS);
    glColor3f(0.65, 0.65, 0.65);
    glVertex2f(45, 68);
    glVertex2f(55, 68);
    glVertex2f(55, 70);
    glVertex2f(45, 70);
    glEnd();

    glBegin(GL_QUADS);
    glColor3f(1.0, 1.0, 0.85);
    glVertex2f(46, 68);
    glVertex2f(54, 68);
    glVertex2f(54, 69);
    glVertex2f(46, 69);
    glEnd();
}

void drawCeilingLight3()//345623
{
    glBegin(GL_QUADS);
    glColor3f(0.65, 0.65, 0.65);
    glVertex2f(75, 68);
    glVertex2f(85, 68);
    glVertex2f(85, 70);
    glVertex2f(75, 70);
    glEnd();

    glBegin(GL_QUADS);
    glColor3f(1.0, 1.0, 0.85);
    glVertex2f(76, 68);
    glVertex2f(84, 68);
    glVertex2f(84, 69);
    glVertex2f(76, 69);
    glEnd();
}

void drawCeilingAC()//345626
{
    glBegin(GL_QUADS);
    glColor3f(0.86, 0.86, 0.85);
    glVertex2f(41, 56);
    glVertex2f(37, 66);
    glVertex2f(62, 66);
    glVertex2f(59, 56);
    glEnd();

    glBegin(GL_QUADS);
    glColor3f(0.7, 0.7, 0.7);
    glVertex2f(41, 56);
    glVertex2f(41, 57);
    glVertex2f(59, 57);
    glVertex2f(59, 56);
    glEnd();

    glBegin(GL_QUADS);
    glColor3f(0.65, 0.65, 0.65);
    glVertex2f(42, 57);
    glVertex2f(39, 65);
    glVertex2f(60, 65);
    glVertex2f(58, 57);
    glEnd();
}


//  DREAM CLOUD

void drawCircle(float cx, float cy, float rx, float ry)
{
    glBegin(GL_POLYGON);
    for (int i = 0; i < 360; i++)
    {
        float a = i * 3.14159f / 180.0f;
        glVertex2f(cx + rx * cos(a), cy + ry * sin(a));
    }
    glEnd();
}

void drawDreamCloud()//502
{
    glColor3f(1.0, 1.0, 1.0);

    drawCircle(5.8, 21.8, 0.3, 0.3);
    drawCircle(6.3, 23.0, 0.45, 0.45);
    drawCircle(6.8, 24.2, 0.6, 0.6);

    drawCircle(3.5, 27.0, 1.5, 1.5);
    drawCircle(5.0, 28.2, 1.8, 1.8);
    drawCircle(7.2, 28.5, 2.0, 2.0);
    drawCircle(9.3, 27.8, 1.7, 1.7);
    drawCircle(10.5, 26.5, 1.4, 1.4);
    drawCircle(8.0, 26.0, 1.7, 1.7);
    drawCircle(5.5, 25.8, 1.4, 1.4);
    glColor3f(0.2, 0.4, 0.9);
    glRasterPos2f(4.5, 27.0);
    const char* txt = "Boring....";
    for (int i = 0; txt[i] != '\0'; i++)
        glutBitmapCharacter(GLUT_BITMAP_HELVETICA_18, txt[i]);
}




// GENERAL REUSABLE BENCH
// x, y = bottom-left corner of the bench
// scale = 1.0 for Row 2, 1.21 for Row 3
void drawBench(float x, float y, float scale)//345624
{
    glPushMatrix();
    glTranslatef(x, y, 0);
    glScalef(scale, scale, 1.0f);

    glBegin(GL_QUADS);
    glColor3f(0.1, 0.1, 0.1);

    glVertex2f(1, 0);
    glVertex2f(2, 0);
    glVertex2f(2, 3);
    glVertex2f(1, 3);

    glVertex2f(12, 0);
    glVertex2f(13, 0);
    glVertex2f(13, 3);
    glVertex2f(12, 3);

    glEnd();

    glBegin(GL_QUADS);
    glColor3f(0.4, 0.2, 0.07);

    glVertex2f(0, 3);
    glVertex2f(14, 3);
    glVertex2f(14, 5);
    glVertex2f(0, 5);

    glEnd();

    glBegin(GL_QUADS);
    glColor3f(0.1, 0.1, 0.1);

    glVertex2f(1, 5);
    glVertex2f(2, 5);
    glVertex2f(2, 7);
    glVertex2f(1, 7);

    glVertex2f(12, 5);
    glVertex2f(13, 5);
    glVertex2f(13, 7);
    glVertex2f(12, 7);

    glEnd();

    glBegin(GL_QUADS);
    glColor3f(0.4, 0.2, 0.07);

    glVertex2f(0, 7);
    glVertex2f(14, 7);
    glVertex2f(14, 8);
    glVertex2f(0, 8);

    glEnd();

    glPopMatrix();
}

// GENERAL REUSABLE SEATED STUDENT
// scale = 1.0 for Row 2, 1.21 for Row 3
// shirtR/G/B = shirt color
// hijab = true for a hijab, false for hair
float eyeMoveX = 0.0f;
void drawStudent(float x, float y,float scale,float shirtR, float shirtG, float shirtB,bool hijab)//345625
{
    glPushMatrix();
    glTranslatef(x, y, 0);
    glScalef(scale, scale, 1.0f);

    // This keeps the original student coordinates unchanged.
    glBegin(GL_POLYGON);
    glColor3f(0.6, 0.38, 0.25);

    glVertex2f(0.66, -2.5);
    glVertex2f(1.09, -2.5);
    glVertex2f(1.09, 0);
    glVertex2f(0.66, 0);

    glEnd();

    glBegin(GL_POLYGON);
    glColor3f(0.6, 0.38, 0.25);

    glVertex2f(1.48, -2.5);
    glVertex2f(1.91, -2.5);
    glVertex2f(1.91, 0);
    glVertex2f(1.48, 0);

    glEnd();

    glBegin(GL_QUADS);
    glColor3f(shirtR, shirtG, shirtB);

    glVertex2f(0, 0);
    glVertex2f(2.57, 0);
    glVertex2f(2.57, 4.08);
    glVertex2f(0, 4.08);

    glEnd();

    if (hijab)
    {
        glBegin(GL_POLYGON);
        glColor3f(0.04, 0.32, 0.36);

        for (int i = 0; i < 360; i++)
        {
            float angle = i * 3.14159f / 180.0f;

            glVertex2f(1.29 + 1.51 * cos(angle),
                       6.12 + 1.7 * sin(angle));
        }

        glEnd();

        glBegin(GL_POLYGON);
        glColor3f(0.7, 0.45, 0.3);

        for (int i = 0; i < 360; i++)
        {
            float angle = i * 3.14159f / 180.0f;

            glVertex2f(1.28+ 0.83 * cos(angle),
                       5.87 + 0.94 * sin(angle));
        }

        glEnd();
    }
    else
    {
        glBegin(GL_POLYGON);
        glColor3f(0.04, 0.03, 0.02);

        for (int i = 0; i < 360; i++)
        {
            float angle = i * 3.14159f / 180.0f;

            glVertex2f(1.28 + 1.59 * cos(angle),
                       6.29 + 1.79 * sin(angle));
        }

        glEnd();

        glBegin(GL_POLYGON);
        glColor3f(0.72, 0.48, 0.32);

        for (int i = 0; i < 360; i++)
        {
            float angle = i * 3.14159f / 180.0f;

            glVertex2f(1.28 + 1.06 * cos(angle),
                       5.95 + 1.19 * sin(angle));
        }

        glEnd();
    }

    glBegin(GL_POLYGON);
    glColor3f(0.02, 0.02, 0.02);

    for (int i = 0; i < 360; i++)
    {
        float angle = i * 3.14159f / 180.0f;

        glVertex2f(0.91 + eyeMoveX + 0.15 * cos(angle),6.12 + 0.17 * sin(angle));
    }

    glEnd();

    glBegin(GL_POLYGON);
    glColor3f(0.02, 0.02, 0.02);

    for (int i = 0; i < 360; i++)
    {
        float angle = i * 3.14159f / 180.0f;

        glVertex2f(1.66 + eyeMoveX + 0.15 * cos(angle),6.12 + 0.17 * sin(angle));
    }

    glEnd();

    // Keep the original fractional coordinates so the hand/arm shape does not disappear.
    glBegin(GL_POLYGON);
    glColor3f(0.6, 0.38, 0.25);

    glVertex2f(-0.01, 3.13);
    glVertex2f(0.45, 2.98);
    glVertex2f(1.18, 1.33);
    glVertex2f(0.73, 1.07);

    glEnd();

    glBegin(GL_POLYGON);
    glColor3f(0.6, 0.38, 0.25);

    glVertex2f(2.59, 3.13);
    glVertex2f(2.13, 2.98);
    glVertex2f(1.45, 1.33);
    glVertex2f(1.81, 1.07);

    glEnd();

    glPopMatrix();
}



// DRAW ALL BENCHES
void drawAllBenches()
{
    drawBench(20, 15.78, 1.0);
    drawBench(34, 16.4,    1.0);
    drawBench(52, 16.4,    1.0);
    drawBench(66, 15.78,  1.0);

    drawBench(14, 9,  1.21);
    drawBench(31, 10,  1.21);
    drawBench(53, 10,  1.21);
    drawBench(70, 9,  1.21);
}


// DRAW ALL SEATED STUDENTS
void drawAllStudents()
{
    drawStudent(28, 20.62,1.0,0.1, 0.3, 0.45,false);
    drawStudent(37, 21.25,1.0,0.45, 0.15, 0.12,true);
    drawStudent(42, 21.25,1.0,0.15, 0.3, 0.25,false);
    drawStudent(55, 21.25,1.0,0.12, 0.25, 0.4,false);
    drawStudent(60, 21.25,1.0,0.45, 0.2, 0.1,true);
    drawStudent(69, 20.62,1.0,0.15, 0.1, 0.3,false);

    drawStudent(24, 14.76,1.21,0.1, 0.3, 0.45,false);
    drawStudent(34, 15.38,1.21,0.45, 0.15, 0.12,true);
    drawStudent(41, 15.38,1.21,0.15, 0.3, 0.25,false);
    drawStudent(63, 15.38,1.21,0.45, 0.2, 0.1,true);
    drawStudent(73, 14.76,1.21,0.15, 0.1, 0.3,false);
    drawStudent(79, 14.76,1.21,0.45, 0.2, 0.4,true);
}

//ANIMATION VARIABLES
// These variables are shared by the human animation/display functions.
int phase = 1;
bool moving = false;
float humanX = 0.0f;
float humanY = 0.0f;
float handAngle = 0.0f;
int handPhase = 0;
const float REACH_ANGLE = 55.0f;
float cloudY = 0.0f;
float humanScale = 1.0f;
bool dreamStarted = false;


// Phase 2 = standing in front of the bench and facing the viewer.
// Phase 3 = sitting on the bench.
float standTimer = 0.0f;
float sitProgress = 0.0f;

void human()
{
    glBegin(GL_POLYGON);
    glColor3f(0,0,0);

    for (int i = 0; i < 360; i++)
    {
        float angle = i * 3.14159f / 180.0f;

        glVertex2f(5 + 2 * cos(angle),20 + 2 * sin(angle));
    }

    glEnd();


    glBegin(GL_QUADS);
    glColor3f(0,0,1);

    glVertex2f(3, 18);
    glVertex2f(7, 18);
    glVertex2f(7, 9);
    glVertex2f(3, 9);

    glEnd();


    glBegin(GL_POLYGON);
    glColor3f(0.72, 0.48, 0.32);

    glVertex2f(2.7, 17.5);
    glVertex2f(3.5, 17.2);
    glVertex2f(0.7, 13);
    glVertex2f(0, 13.5);

    glEnd();


    // Same arm as before, but rotated during the animation.
    glPushMatrix();

    // Shoulder is the rotation point.
    glTranslatef(7.3, 17.5, 0);
    glRotatef(handAngle, 0, 0, 1);

    glBegin(GL_POLYGON);
    glColor3f(0.72, 0.48, 0.32);

    glVertex2f(0, 0);
    glVertex2f(-0.8, -0.3);
    glVertex2f(2, -4.5);
    glVertex2f(2.7, -4);

    glEnd();

    glPopMatrix();


    glBegin(GL_QUADS);
    glColor3f(0.1, 0.1, 0.1);

    glVertex2f(3, 9);
    glVertex2f(4, 9);
    glVertex2f(4, 3);
    glVertex2f(3, 3);

    glEnd();


    glBegin(GL_QUADS);
    glColor3f(0.1, 0.1, 0.1);

    glVertex2f(6, 9);
    glVertex2f(7, 9);
    glVertex2f(7, 3);
    glVertex2f(6, 3);

    glEnd();
}

//FRONT-FACING HUMAN
// Used only in Phase 2.  The original human() is not changed.
void humanFront()
{
    glBegin(GL_POLYGON);
    glColor3f(0.04, 0.03, 0.02);

    for (int i = 0; i < 360; i++)
    {
        float angle = i * 3.14159f / 180.0f;
        glVertex2f(5 + 2 * cos(angle),
                   20 + 2 * sin(angle));
    }
    glEnd();

    glBegin(GL_POLYGON);
    glColor3f(0.72, 0.48, 0.32);

    for (int i = 0; i < 360; i++)
    {
        float angle = i * 3.14159f / 180.0f;
        glVertex2f(5 + 1.45 * cos(angle),19.75 + 1.55 * sin(angle));
    }
    glEnd();

    glBegin(GL_POLYGON);
    glColor3f(0.02, 0.02, 0.02);
    for (int i = 0; i < 360; i++)
    {
        float angle = i * 3.14159f / 180.0f;
        glVertex2f(4.45 + 0.12 * cos(angle),20.05 + 0.15 * sin(angle));
    }
    glEnd();

    glBegin(GL_POLYGON);
    glColor3f(0.02, 0.02, 0.02);
    for (int i = 0; i < 360; i++)
    {
        float angle = i * 3.14159f / 180.0f;
        glVertex2f(5.55 + 0.12 * cos(angle),
                   20.05 + 0.15 * sin(angle));
    }
    glEnd();

    glBegin(GL_QUADS);
    glColor3f(0.2, 0.3, 0.8);
    glVertex2f(3, 18);
    glVertex2f(7, 18);
    glVertex2f(7, 9);
    glVertex2f(3, 9);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3f(0.72, 0.48, 0.32);
    glVertex2f(2.7, 17.5);
    glVertex2f(3.5, 17.2);
    glVertex2f(0.7, 13);
    glVertex2f(0, 13.5);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3f(0.72, 0.48, 0.32);
    glVertex2f(7.3, 17.5);
    glVertex2f(6.5, 17.2);
    glVertex2f(9.3, 13);
    glVertex2f(10, 13.5);
    glEnd();

    glBegin(GL_QUADS);
    glColor3f(0.1, 0.1, 0.1);
    glVertex2f(3, 9);
    glVertex2f(4, 9);
    glVertex2f(4, 3);
    glVertex2f(3, 3);
    glEnd();

    glBegin(GL_QUADS);
    glColor3f(0.1, 0.1, 0.1);
    glVertex2f(6, 9);
    glVertex2f(7, 9);
    glVertex2f(7, 3);
    glVertex2f(6, 3);
    glEnd();
}

//SEATED HUMAN
// Used only in Phase 3.  The human is placed on ROW3 BENCH1.
void humanSeated()
{
    glBegin(GL_POLYGON);
    glColor3f(0.04, 0.03, 0.02);
    for (int i = 0; i < 360; i++)
    {
        float angle = i * 3.14159f / 180.0f;
        glVertex2f(5 + 2 * cos(angle),20 + 2 * sin(angle));
    }
    glEnd();

    glBegin(GL_POLYGON);
    glColor3f(0.72, 0.48, 0.32);
    for (int i = 0; i < 360; i++)
    {
        float angle = i * 3.14159f / 180.0f;
        glVertex2f(5 + 1.45 * cos(angle),19.75 + 1.55 * sin(angle));
    }
    glEnd();

    glBegin(GL_POLYGON);
    glColor3f(0.02, 0.02, 0.02);
    for (int i = 0; i < 360; i++)
    {
        float angle = i * 3.14159f / 180.0f;
        glVertex2f(4.45 + 0.12 * cos(angle),20.05 + 0.15 * sin(angle));
    }
    glEnd();

    glBegin(GL_POLYGON);
    glColor3f(0.02, 0.02, 0.02);
    for (int i = 0; i < 360; i++)
    {
        float angle = i * 3.14159f / 180.0f;
        glVertex2f(5.55 + 0.12 * cos(angle),20.05 + 0.15 * sin(angle));
    }
    glEnd();

    glBegin(GL_QUADS);
    glColor3f(0.2, 0.3, 0.8);
    glVertex2f(3, 18);
    glVertex2f(7, 18);
    glVertex2f(7, 14);
    glVertex2f(3, 14);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3f(0.72, 0.48, 0.32);
    glVertex2f(2.7, 17.5);
    glVertex2f(3.5, 17.2);
    glVertex2f(2.3, 14.2);
    glVertex2f(1.6, 14.5);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3f(0.72, 0.48, 0.32);
    glVertex2f(7.3, 17.5);
    glVertex2f(6.5, 17.2);
    glVertex2f(7.7, 14.2);
    glVertex2f(8.4, 14.5);
    glEnd();

glBegin(GL_QUADS);
glColor3f(0.1, 0.1, 0.1);

glVertex2f(3, 14);
glVertex2f(4, 14);
glVertex2f(4, 7);
glVertex2f(3, 7);

glEnd();


glBegin(GL_QUADS);
glColor3f(0.1, 0.1, 0.1);

glVertex2f(6, 14);
glVertex2f(7, 14);
glVertex2f(7, 7);
glVertex2f(6, 7);

glEnd();
}
// CLASSROOM DRAW
void drawClassroom()
{
    drawCeiling();
    drawCeilingTiles();
    drawBackWall();
    drawLeftSideWall();
    drawRightSideWall();
    drawFloor();
    drawFloorLines();
    drawProjectorScreen();
    drawScreenLogo();
    drawRoofSupports();
    drawCeilingLight1();
    drawCeilingLight2();
    drawCeilingLight3();

    // All benches are generated from one reusable function.
    drawAllBenches();

    // All seated students are generated from one reusable function.
    drawAllStudents();

    drawCeilingAC();

    drawText(40, 49,"American International University - Bangladesh (AIUB)");
}


// PHASE 1 DISPLAY
// Original classroom + original backward-facing walking human.
void display3()
{
    glClear(GL_COLOR_BUFFER_BIT);

    drawClassroom();

    glPushMatrix();
    glTranslatef(humanX, humanY, 0);
    human();
    glPopMatrix();

    glFlush();
}

// PHASE 2 DISPLAY
void display4()
{
    glClear(GL_COLOR_BUFFER_BIT);

    drawClassroom();

    glPushMatrix();
    glTranslatef(humanX, humanY, 0);
    humanFront();
    glPopMatrix();

    glFlush();
}

//PHASE 3 DISPLAY
void display5()
{
    glClear(GL_COLOR_BUFFER_BIT);

    float xc = humanX + 6.0f;
    float yc = (humanY - (5.1f * sitProgress)) + 18.0f;
    glPushMatrix();


    glTranslatef(xc, yc, 0);
    glScalef(humanScale, humanScale, 1.0f);
    glTranslatef(-xc, -yc, 0);

    drawClassroom();

    glPushMatrix();

    float seatedY = humanY - (5.1f * sitProgress);

    glTranslatef(humanX, seatedY, 0);

    humanSeated();

    glPopMatrix();

    if (sitProgress >= 1.0f)
    {
        glPushMatrix();

        glTranslatef(humanX, seatedY, 0);
        glTranslatef(0, cloudY, 0);
        glPopMatrix();
    }

    glPopMatrix();

    glFlush();
}
void display61()
{
    glClear(GL_COLOR_BUFFER_BIT);

    float xc = humanX + 6.0f;
    float yc = humanY - 5.1f + 18.0f;

    glPushMatrix();


    glTranslatef(xc, yc, 0);
    glScalef(humanScale, humanScale, 1.0f);
    glTranslatef(-xc, -yc, 0);

    drawClassroom();

    glPushMatrix();

    float seatedY = humanY - 5.1f;

    glTranslatef(humanX, seatedY, 0);
    humanSeated();
    glPopMatrix();

    // DREAM CLOUD

    if (dreamStarted)
    {
        glPushMatrix();
        glTranslatef(humanX, seatedY, 0);
        glTranslatef(0, cloudY, 0);
        drawDreamCloud();
        glPopMatrix();
    }

    glPopMatrix();

    glFlush();
}

//KEYBOARD
void keyboard(unsigned char key, int x, int y)
{
    //PHASE 1
    if (phase == 1)
    {
        if (key == 'w' || key == 'W')
        {
            moving = true;
        }
    }

    else if (phase == 4)
    {
        if (key == 'd' || key == 'D')
        {
            dreamStarted = true;
        }
    }

    glutPostRedisplay();
}
//TIMER
void timer(int value)
{
    // PHASE 1
    if (phase == 1)
    {
if (moving)
{
    humanX += 0.05f;
    humanY += 0.02f;

    eyeMoveX -= 0.02f;
    if (eyeMoveX <= -0.5f)
        eyeMoveX = -0.5f;

    if (humanX >= 15.0f)
    {
        humanX = 15.0f;
        humanY = 6.0f;
        moving = false;
        phase = 2;
        standTimer = 0.0f;
    }
    glutPostRedisplay();
}
    }

    else if (phase == 2)
    {
        standTimer += 0.03f;

        if (standTimer >= 1.5f)
        {
            phase = 3;
            sitProgress = 0.0f;
        }

        glutPostRedisplay();
    }

else if (phase == 3)
{
    if (sitProgress < 1.0f)
    {
        sitProgress += 0.04f;
        if (sitProgress > 1.0f)
            sitProgress = 1.0f;
    }

    if (sitProgress >= 1.0f)
    {
        sitProgress = 1.0f;
        eyeMoveX = 0.0f;
        phase = 4;
        cloudY = 0.0f;
        humanScale = 1.0f;
        dreamStarted = false;
    }

    glutPostRedisplay();
}
else if (phase == 4)
{
    if (dreamStarted)
    {
        cloudY += 0.015f;
        if (cloudY >= 5.0f)
            cloudY = 0.0f;
        if (humanScale < 1.8f)
        {
            humanScale += 0.01f;
            if (humanScale > 1.8f)
                humanScale = 1.8f;
        }
    }

    glutPostRedisplay();
}
}


void display6()
{
    if (phase == 1)
        display3();
    else if (phase == 2)
        display4();
    else if (phase == 3)
        display5();
    else if (phase == 4)
        display61();
}



}

namespace Teacher {

using namespace std;

double angle = 0;


float armY = 0.0f;
float armDirection = 1.0f;
bool armMoving = false;

const float ARM_MOVE_HEIGHT = 4.0f;



float lipAnim = 0.0f;
float lipScale = 1.0f;



const float TEACHER_SCALE = 1.15f;

const float TEACHER_CENTER_X = 25.0f;
const float TEACHER_CENTER_Y = 27.0f;



float teacherX = 25.0f;

const float TEACHER_TARGET_X = 85.0f;

const float TEACHER_MOVE_SPEED = 0.25f;

bool teacherMoving = false;
float teacherDirection = 1.0f; // 1 = forward/right, -1 = backward/left



const float SCREEN_FOLDED_HEIGHT = 1.2f;

const float SCREEN_FULL_HEIGHT = 31.0f;

const float SCREEN_TOP_Y = 70.0f;

float screenHeight = SCREEN_FOLDED_HEIGHT;

const float SCREEN_UNFOLD_SPEED = 0.35f;

bool screenMoving = false;

bool screenUnfolding = true;




bool projectorShapesVisible = false;


bool questionMode = false;



void drawCircle(float cx, float cy, float r)
{
    glBegin(GL_POLYGON);

    for (int i = 0; i < 360; i++)
    {
        float a = i * 3.14159 / 180.0;

        float x = cx + r * cos(a);
        float y = cy + r * sin(a);

        glVertex2f(x, y);
    }

    glEnd();
}



void init()
{
    glClearColor(0.85, 0.85, 0.87, 1);

    gluOrtho2D(0, 100, 0, 75);
}



void backWall()
{
    glBegin(GL_QUADS);

    glColor3f(0.95, 0.95, 0.94);

    glVertex2f(0, 7);
    glVertex2f(100, 7);
    glVertex2f(100, 75);
    glVertex2f(0, 75);

    glEnd();
}


// FLOOR

void floor()
{
    glBegin(GL_QUADS);

    glColor3f(0.82, 0.82, 0.80);

    glVertex2f(0, 0);
    glVertex2f(100, 0);
    glVertex2f(100, 7);
    glVertex2f(0, 7);

    glEnd();
}


void floorBorder()
{
    glBegin(GL_QUADS);

    glColor3f(0.72, 0.71, 0.67);

    glVertex2f(0, 7);
    glVertex2f(100, 7);
    glVertex2f(100, 8);
    glVertex2f(0, 8);

    glEnd();
}


void floorTileLines()
{
    glBegin(GL_LINES);

    glColor3f(0.68, 0.68, 0.66);

    glVertex2f(25, 0);
    glVertex2f(25, 7);

    glVertex2f(50, 0);
    glVertex2f(50, 7);

    glVertex2f(75, 0);
    glVertex2f(75, 7);

    glEnd();
}



void whiteboard()
{
    glBegin(GL_QUADS);

    glColor3f(0.99, 0.99, 0.98);

    glVertex2f(10, 39);
    glVertex2f(97, 39);
    glVertex2f(97, 68);
    glVertex2f(10, 68);

    glEnd();
}


void whiteboardTopFrame()
{
    glBegin(GL_QUADS);

    glColor3f(0.48, 0.27, 0.09);

    glVertex2f(9.5, 68);
    glVertex2f(97.5, 68);
    glVertex2f(97.5, 69.3);
    glVertex2f(9.5, 69.3);

    glEnd();
}


void whiteboardBottomFrame()
{
    glBegin(GL_QUADS);

    glColor3f(0.48, 0.27, 0.09);

    glVertex2f(9.5, 38);
    glVertex2f(97.5, 38);
    glVertex2f(97.5, 40);
    glVertex2f(9.5, 40);

    glEnd();
}


void whiteboardLeftFrame()
{
    glBegin(GL_QUADS);

    glColor3f(0.48, 0.27, 0.09);

    glVertex2f(9.5, 38);
    glVertex2f(10.5, 38);
    glVertex2f(10.5, 69);
    glVertex2f(9.5, 69);

    glEnd();
}


void whiteboardRightFrame()
{
    glBegin(GL_QUADS);

    glColor3f(0.48, 0.27, 0.09);

    glVertex2f(97, 38);
    glVertex2f(98, 38);
    glVertex2f(98, 69);
    glVertex2f(97, 69);

    glEnd();
}



void boardText()
{
    glColor3f(0.0, 0.0, 0.0);

    glRasterPos2f(70.0, 58.0);

    const char* text1 = "OpenGL Polygon()";

    for (int i = 0; text1[i] != '\0'; i++)
    {
        glutBitmapCharacter(GLUT_BITMAP_HELVETICA_18, text1[i]);
    }


    glColor3f(0.0, 0.0, 0.0);

    glRasterPos2f(69.0, 54.0);

    const char* text2 = "glVertex2F()";

    for (int i = 0; text2[i] != '\0'; i++)
    {
        glutBitmapCharacter(GLUT_BITMAP_HELVETICA_18, text2[i]);
    }
}


// PROJECTOR SCREEN

void projectorScreen()
{
    float bottomY = SCREEN_TOP_Y - screenHeight;

    glBegin(GL_QUADS);

    glColor3f(1, 1, 1);

    glVertex2f(10, bottomY);
    glVertex2f(64, bottomY);
    glVertex2f(64, SCREEN_TOP_Y);
    glVertex2f(10, SCREEN_TOP_Y);

    glEnd();
}



void screenLeftBorder()
{
    float bottomY = SCREEN_TOP_Y - screenHeight;

    glBegin(GL_QUADS);

    glColor3f(0.02, 0.02, 0.02);

    glVertex2f(9.2, bottomY);
    glVertex2f(10.4, bottomY);
    glVertex2f(10.4, 71);
    glVertex2f(9.2, 71);

    glEnd();
}



void screenRightBorder()
{
    float bottomY = SCREEN_TOP_Y - screenHeight;

    glBegin(GL_QUADS);

    glColor3f(0.02, 0.02, 0.02);

    glVertex2f(63.5, bottomY);
    glVertex2f(64.7, bottomY);
    glVertex2f(64.7, 71);
    glVertex2f(63.5, 71);

    glEnd();
}



void screenBottomBorder()
{
    float bottomY = SCREEN_TOP_Y - screenHeight;

    glBegin(GL_QUADS);

    glColor3f(0.02, 0.02, 0.02);

    glVertex2f(9.2, bottomY);
    glVertex2f(64.7, bottomY);
    glVertex2f(64.7, bottomY + 1.3f);
    glVertex2f(9.2, bottomY + 1.3f);

    glEnd();
}



void screenTopBar()
{
    glBegin(GL_QUADS);

    glColor3f(0.76, 0.76, 0.74);

    glVertex2f(8.5, 70.5);
    glVertex2f(65.2, 70.5);
    glVertex2f(65.2, 71.5);
    glVertex2f(8.5, 71.5);

    glEnd();
}



void screenRollers()
{
    glColor3f(0.55, 0.55, 0.53);

    drawCircle(9, 71, 0.65);
    drawCircle(65, 71, 0.65);
}



void screenHangingString()
{
    float bottomY = SCREEN_TOP_Y - screenHeight;

    glBegin(GL_LINES);

    glColor3f(0.55, 0.55, 0.55);

    glVertex2f(37, bottomY);
    glVertex2f(37, bottomY - 18);

    glEnd();
}



void stringHolder()
{
    float bottomY = SCREEN_TOP_Y - screenHeight;

    glBegin(GL_LINES);

    glColor3f(0.55, 0.55, 0.55);

    glVertex2f(35.8, bottomY);
    glVertex2f(35.8, bottomY - 0.8);

    glVertex2f(35.8, bottomY - 0.8);
    glVertex2f(38.2, bottomY - 0.8);

    glVertex2f(38.2, bottomY - 0.8);
    glVertex2f(38.2, bottomY);

    glEnd();
}



void projectorTriangle()
{

    if (!projectorShapesVisible || questionMode)
        return;

    glBegin(GL_TRIANGLES);

    glColor3f(1, 0, 0);

    glVertex2f(45, 60);
    glVertex2f(40, 50);
    glVertex2f(50, 50);

    glEnd();
}



void projectorRectangle()
{

    if (!projectorShapesVisible || questionMode)
        return;

    glBegin(GL_QUADS);

    glColor3f(0, 0, 1);

    glVertex2f(26, 50);
    glVertex2f(36, 50);
    glVertex2f(36, 60);
    glVertex2f(26, 60);

    glEnd();
}



void questionText()
{

    if (!questionMode)
        return;

    glColor3f(0.05, 0.05, 0.05);


    glRasterPos2f(15.0, 60.0);

    const char* text1 =
        "Now the question is how we can draw";

    for (int i = 0; text1[i] != '\0'; i++)
    {
        glutBitmapCharacter(
            GLUT_BITMAP_HELVETICA_18,
            text1[i]
        );
    }



    glRasterPos2f(18.0, 55.0);

    const char* text2 =
        "Rectangle and Triangle using OpenGL";

    for (int i = 0; text2[i] != '\0'; i++)
    {
        glutBitmapCharacter(
            GLUT_BITMAP_HELVETICA_18,
            text2[i]
        );
    }
}



void clock()
{
    glColor3f(0.72, 0.72, 0.70);

    drawCircle(80.75, 71.5, 1.8);

    glColor3f(0.97, 0.97, 0.95);

    drawCircle(80.75, 71.5, 1.45);

    glBegin(GL_LINES);

    glColor3f(0.10, 0.10, 0.10);

    glVertex2f(80.75, 72.88);
    glVertex2f(80.75, 72.64);

    glVertex2f(80.75, 70.12);
    glVertex2f(80.75, 70.36);

    glVertex2f(79.25, 71.5);
    glVertex2f(79.49, 71.5);

    glVertex2f(82.01, 71.5);
    glVertex2f(82.25, 71.5);

    glEnd();


    glPushMatrix();

    glTranslated(80.75, 71.5, 0);

    glRotated(angle, 0, 0, 1);

    glBegin(GL_LINES);

    glColor3f(0.05, 0.05, 0.05);

    glVertex2f(0, 0);
    glVertex2f(0, 1.05);

    glEnd();


    glBegin(GL_LINES);

    glColor3f(0.05, 0.05, 0.05);

    glVertex2f(0, 0);
    glVertex2f(-0.55, 0.55);

    glEnd();

    glPopMatrix();


    glColor3f(0.05, 0.42, 0.60);

    drawCircle(80.75, 71.5, 0.22);
}



void leftSocket()
{
    glBegin(GL_QUADS);

    glColor3f(0.90, 0.90, 0.88);

    glVertex2f(55, 10);
    glVertex2f(59, 10);
    glVertex2f(59, 14);
    glVertex2f(55, 14);

    glEnd();


    glColor3f(0.08, 0.08, 0.08);

    drawCircle(56.6, 12.3, 0.22);
    drawCircle(57.4, 12.3, 0.22);
}


void rightSocket()
{
    glBegin(GL_QUADS);

    glColor3f(0.90, 0.90, 0.88);

    glVertex2f(94, 10);
    glVertex2f(98, 10);
    glVertex2f(98, 13.5);
    glVertex2f(94, 13.5);

    glEnd();


    glColor3f(0.08, 0.08, 0.08);

    drawCircle(95, 11.7, 0.22);
    drawCircle(97, 11.7, 0.22);
}



void cable()
{
    glBegin(GL_LINES);

    glColor3f(0.02, 0.02, 0.02);

    glVertex2f(56.5, 10);
    glVertex2f(56, 8.5);

    glVertex2f(56, 8.5);
    glVertex2f(54, 6.5);

    glVertex2f(54, 6.5);
    glVertex2f(51, 5);

    glVertex2f(51, 5);
    glVertex2f(47, 3.8);

    glVertex2f(47, 3.8);
    glVertex2f(43, 2.8);

    glVertex2f(43, 2.8);
    glVertex2f(39, 1.8);

    glVertex2f(39, 1.8);
    glVertex2f(35, 0.7);

    glEnd();


    glBegin(GL_LINES);

    glColor3f(0.55, 0.05, 0.02);

    glVertex2f(56.8, 10);
    glVertex2f(56.2, 8.5);

    glVertex2f(56.2, 8.5);
    glVertex2f(54.2, 6.5);

    glVertex2f(54.2, 6.5);
    glVertex2f(51.2, 5);

    glVertex2f(51.2, 5);
    glVertex2f(47.2, 3.8);

    glVertex2f(47.2, 3.8);
    glVertex2f(43.2, 2.8);

    glVertex2f(43.2, 2.8);
    glVertex2f(39.2, 1.8);

    glVertex2f(39.2, 1.8);
    glVertex2f(35.2, 0.7);

    glEnd();
}



void teacherTrouserLeft()
{
    glBegin(GL_QUADS);

    glColor3f(0.10, 0.14, 0.20);

    glVertex2f(23.4, 18);
    glVertex2f(24.6, 18);
    glVertex2f(24.6, 8);
    glVertex2f(23.4, 8);

    glEnd();
}



void teacherTrouserRight()
{
    glBegin(GL_QUADS);

    glColor3f(0.09, 0.13, 0.19);

    glVertex2f(25.4, 18);
    glVertex2f(26.6, 18);
    glVertex2f(26.6, 8);
    glVertex2f(25.4, 8);

    glEnd();
}



void teacherBody()
{
    glBegin(GL_QUADS);

    glColor3f(0.88, 0.55, 0.65);

    glVertex2f(22.5, 38);
    glVertex2f(27.5, 38);

    glVertex2f(27.5, 18);
    glVertex2f(22.5, 18);

    glEnd();
}



void teacherNeck()
{
    glBegin(GL_QUADS);

    glColor3f(0.59, 0.37, 0.24);

    glVertex2f(24.25, 38);
    glVertex2f(25.75, 38);

    glVertex2f(25.75, 40.1);
    glVertex2f(24.25, 40.1);

    glEnd();
}



void teacherHead()
{
    glColor3f(0.59, 0.37, 0.24);

    drawCircle(25.0, 42.7, 3.2);
}



void teacherEar()
{
    glColor3f(0.55, 0.33, 0.21);

    drawCircle(21.95, 42.7, 0.55);
    drawCircle(28.05, 42.7, 0.55);
}



void teacherHair()
{
    glBegin(GL_POLYGON);

    glColor3f(0.02, 0.02, 0.02);

    glVertex2f(22.0, 43.5);
    glVertex2f(22.3, 45.2);
    glVertex2f(23.5, 45.8);
    glVertex2f(25.0, 46.0);
    glVertex2f(26.5, 45.7);
    glVertex2f(27.7, 44.8);
    glVertex2f(28.0, 43.5);

    glVertex2f(26.8, 44.2);
    glVertex2f(25.0, 44.5);
    glVertex2f(23.2, 44.2);

    glEnd();
}



void teacherEyes()
{
    glColor3f(0.01, 0.01, 0.01);

    drawCircle(23.8, 42.9, 0.18);
    drawCircle(26.2, 42.9, 0.18);
}



void teacherNose()
{
    glBegin(GL_LINES);

    glColor3f(0.35, 0.18, 0.12);

    glVertex2f(25.45, 42.6);
    glVertex2f(25.8, 42.15);

    glEnd();
}



void teacherLips()
{
    const float lipCenterX = 25.0f;
    const float lipCenterY = 41.525f;

    glPushMatrix();

    glTranslatef(lipCenterX, lipCenterY, 0.0f);

    glScalef(lipScale, lipScale, 1.0f);

    glTranslatef(-lipCenterX, -lipCenterY, 0.0f);

    glBegin(GL_POLYGON);

    glColor3f(0.45, 0.08, 0.08);

    glVertex2f(24.35, 41.7);
    glVertex2f(25.65, 41.7);

    glVertex2f(25.35, 41.35);
    glVertex2f(24.65, 41.35);

    glEnd();

    glPopMatrix();
}



void teacherLeftArm()
{
    glBegin(GL_QUADS);

    glColor3f(0.88, 0.55, 0.65);

    glVertex2f(22.5, 36.5);
    glVertex2f(23.6, 36.2);

    glVertex2f(20.8, 32.2);
    glVertex2f(20.1, 32.7);

    glEnd();
}



void teacherLeftHand()
{
    glColor3f(0.59, 0.37, 0.24);

    drawCircle(20.45, 32.45, 0.65);
}



void teacherRightArm()
{
    glPushMatrix();

    glBegin(GL_QUADS);

    glColor3f(0.88, 0.55, 0.65);

    glVertex2f(26.4, 36.2);
    glVertex2f(27.5, 36.5);

    glVertex2f(30.2, 32.5 + armY);
    glVertex2f(29.5, 32.0 + armY);

    glEnd();

    glPopMatrix();
}



void teacherRightHand()
{
    glPushMatrix();

    glColor3f(0.59, 0.37, 0.24);

    drawCircle(30.0, 32.25 + armY, 0.65);

    glPopMatrix();
}



void teacherLanyard()
{
    glColor3f(0.02, 0.35, 0.70);

    glBegin(GL_QUADS);

    glVertex2f(23.35, 38.0);
    glVertex2f(23.70, 38.0);

    glVertex2f(24.35, 24.2);
    glVertex2f(24.0, 24.2);

    glEnd();


    glBegin(GL_QUADS);

    glVertex2f(26.35, 38.0);
    glVertex2f(26.65, 38.0);

    glVertex2f(26.15, 24.2);
    glVertex2f(25.85, 24.2);

    glEnd();
}



void idCard()
{
    glBegin(GL_QUADS);

    glColor3f(0.94, 0.95, 0.93);

    glVertex2f(23.7, 24.2);
    glVertex2f(26.3, 24.2);

    glVertex2f(26.3, 22.6);
    glVertex2f(23.7, 22.6);

    glEnd();
}



void idCardBorder()
{
    glBegin(GL_LINE_LOOP);

    glColor3f(0.35, 0.35, 0.35);

    glVertex2f(23.7, 24.2);
    glVertex2f(26.3, 24.2);

    glVertex2f(26.3, 22.4);
    glVertex2f(23.7, 22.4);

    glEnd();
}



void idCardPhoto()
{
    glBegin(GL_QUADS);

    glColor3f(0.58, 0.63, 0.63);

    glVertex2f(23.9, 23.75);
    glVertex2f(24.8, 23.75);

    glVertex2f(24.8, 23.15);
    glVertex2f(23.9, 23.15);

    glEnd();
}



void idCardDetails()
{
    glBegin(GL_LINES);

    glColor3f(0.30, 0.30, 0.30);

    glVertex2f(25.1, 23.75);
    glVertex2f(26.0, 23.75);

    glVertex2f(25.1, 23.40);
    glVertex2f(26.0, 23.40);

    glVertex2f(25.0, 23.05);
    glVertex2f(25.9, 23.05);

    glEnd();
}



void teacher()
{
    glPushMatrix();

    glTranslatef(
        teacherX - TEACHER_CENTER_X,
        0.0f,
        0.0f
    );


    glPushMatrix();

    glTranslatef(
        TEACHER_CENTER_X,
        TEACHER_CENTER_Y,
        0.0f
    );

    glScalef(
        TEACHER_SCALE,
        TEACHER_SCALE,
        1.0f
    );

    glTranslatef(
        -TEACHER_CENTER_X,
        -TEACHER_CENTER_Y,
        0.0f
    );


    teacherTrouserLeft();
    teacherTrouserRight();

    teacherBody();

    teacherNeck();

    teacherHead();

    teacherEar();
    teacherHair();

    teacherEyes();
    teacherNose();

    teacherLips();

    teacherLeftArm();
    teacherLeftHand();

    teacherRightArm();
    teacherRightHand();

    teacherLanyard();

    idCard();
    idCardBorder();
    idCardPhoto();
    idCardDetails();

    glPopMatrix();

    glPopMatrix();
}


void Laptop()
{
    glBegin(GL_QUADS);

    glColor3f(0, 0, 0);

    glVertex2f(12, 27);
    glVertex2f(9, 37);
    glVertex2f(17, 37);
    glVertex2f(20, 27);

    glEnd();
}

void podiumTop()
{
    glBegin(GL_QUADS);

    glColor3f(0.78, 0.78, 0.76);

    glVertex2f(2, 23);
    glVertex2f(30, 23);
    glVertex2f(30, 27);
    glVertex2f(2, 27);

    glEnd();
}


void podiumTopEdge()
{
    glBegin(GL_QUADS);

    glColor3f(0.67, 0.67, 0.65);

    glVertex2f(2, 27);
    glVertex2f(30, 27);
    glVertex2f(30, 28);
    glVertex2f(2, 28);

    glEnd();
}


void podiumFront()
{
    glBegin(GL_QUADS);

    glColor3f(0.82, 0.82, 0.80);

    glVertex2f(2, 8);
    glVertex2f(27, 8);
    glVertex2f(27, 23);
    glVertex2f(2, 23);

    glEnd();
}


void podiumRightSide()
{
    glBegin(GL_QUADS);

    glColor3f(0.68, 0.68, 0.66);

    glVertex2f(27, 8);
    glVertex2f(30, 10);
    glVertex2f(30, 25);
    glVertex2f(27, 23);

    glEnd();
}


void podiumLowerPart()
{
    glBegin(GL_QUADS);

    glColor3f(0.78, 0.78, 0.76);

    glVertex2f(8, 0);
    glVertex2f(25, 0);
    glVertex2f(25, 8);
    glVertex2f(8, 8);

    glEnd();
}


void podiumRightEdge()
{
    glBegin(GL_QUADS);

    glColor3f(0.62, 0.62, 0.60);

    glVertex2f(25, 0);
    glVertex2f(27, 1);
    glVertex2f(27, 8);
    glVertex2f(25, 8);

    glEnd();
}


void podium()
{
    podiumTop();
    podiumTopEdge();
    podiumFront();
    podiumRightSide();
    podiumLowerPart();
    podiumRightEdge();
     Laptop();
}



void keyboard(unsigned char key, int x, int y)
{

    if (key == 'l' || key == 'L')
    {
        armMoving = !armMoving;
    }



    if (key == 'm' || key == 'M')
    {
        screenMoving = true;

        armMoving = true;



        if (screenHeight <= SCREEN_FOLDED_HEIGHT + 0.01f)
        {
            screenUnfolding = true;

            projectorShapesVisible = false;

            questionMode = false;
        }



        else if (screenHeight >= SCREEN_FULL_HEIGHT - 0.01f)
        {
            screenUnfolding = false;

            projectorShapesVisible = false;

            questionMode = false;
        }



        else
        {
            screenUnfolding = !screenUnfolding;

            if (!screenUnfolding)
            {
                projectorShapesVisible = false;
                questionMode = false;
            }
            else
            {
                projectorShapesVisible = false;
                questionMode = false;
            }
        }
    }



    if (key == 'a' || key == 'A')
    {

        if (screenHeight >= SCREEN_FULL_HEIGHT - 0.01f)
        {
            questionMode = !questionMode;

            armMoving = true;
        }
    }



    if (key == 'r' || key == 'R')
    {

        if (teacherMoving)
        {
            teacherDirection = -teacherDirection;
        }
        else
        {
            if (teacherX <= TEACHER_CENTER_X + 0.01f)
            {
                teacherDirection = 1.0f;
            }
            else if (teacherX >= TEACHER_TARGET_X - 0.01f)
            {
                teacherDirection = -1.0f;
            }

            teacherMoving = true;
        }
    }



    if (key == 27)
    {
        exit(0);
    }
}


// TIMER

void timer(int value)
{

    angle -= 1;

    if (angle <= -360)
        angle = 0;



    if (armMoving)
    {
        armY += 0.08f * armDirection;


        if (armY >= ARM_MOVE_HEIGHT)
        {
            armY = ARM_MOVE_HEIGHT;

            armDirection = -1.0f;
        }


        if (armY <= 0.0f)
        {
            armY = 0.0f;

            armDirection = 1.0f;
        }


        lipAnim += 0.35f;

        lipScale =
            1.0f +
            0.18f * sin(lipAnim);
    }
    else
    {
        lipScale +=
            (1.0f - lipScale) * 0.20f;


        if (fabs(lipScale - 1.0f) < 0.001f)
        {
            lipScale = 1.0f;
        }
    }



    if (screenMoving)
    {

        if (screenUnfolding)
        {
            screenHeight +=
                SCREEN_UNFOLD_SPEED;


            if (screenHeight >= SCREEN_FULL_HEIGHT)
            {

                screenHeight =
                    SCREEN_FULL_HEIGHT;

                screenMoving = false;

                armMoving = false;


                projectorShapesVisible = true;

                questionMode = false;
            }
        }


        else
        {
            screenHeight -=
                SCREEN_UNFOLD_SPEED;


            if (screenHeight <= SCREEN_FOLDED_HEIGHT)
            {
                screenHeight =
                    SCREEN_FOLDED_HEIGHT;

                screenMoving = false;

                armMoving = false;

                projectorShapesVisible = false;

                questionMode = false;
            }
        }
    }



    if (teacherMoving)
    {
        teacherX +=
            TEACHER_MOVE_SPEED * teacherDirection;

        if (teacherDirection > 0.0f &&
            teacherX >= TEACHER_TARGET_X)
        {
            teacherX =
                TEACHER_TARGET_X;

            teacherMoving = false;
        }

        if (teacherDirection < 0.0f &&
            teacherX <= TEACHER_CENTER_X)
        {
            teacherX =
                TEACHER_CENTER_X;

            teacherMoving = false;
        }
    }



    glutPostRedisplay();
}


// DISPLAY

void display7()
{
    glClear(GL_COLOR_BUFFER_BIT);



    backWall();


    // FLOOR

    floor();

    floorBorder();

    floorTileLines();



    whiteboard();

    whiteboardTopFrame();
    whiteboardBottomFrame();
    whiteboardLeftFrame();
    whiteboardRightFrame();



    boardText();


    // PROJECTOR SCREEN

    projectorScreen();

    screenLeftBorder();
    screenRightBorder();
    screenBottomBorder();

    screenTopBar();

    screenRollers();



    screenHangingString();

    stringHolder();



    projectorRectangle();



    projectorTriangle();



    questionText();



    clock();



    leftSocket();
    rightSocket();



    cable();


    // TEACHER

    teacher();



    podium();


    glFlush();
}


// MAIN



}

namespace Football {

#define PI 3.1416


float ballStartX = 45.0f;
float ballStartY = 12.5f;

float leftX   = 42.5f;
float centerX = 50.0f;
float rightX  = 57.5f;

float ballTargetX = centerX;
float ballTargetY = 33.0f;

float ballX = ballStartX;
float ballY = ballStartY;

float t = 0.0f;

bool ballInFlight = false;
bool goalScored = false;
bool saved = false;
bool notGoal = false;



int shotMode = 0;



float gkDefaultX = 50.0f;
float gkX = gkDefaultX;



int resetCounter = 0;



int   introPhase   = 0;
float bubbleGrow   = 0.4f;
float introTimer   = 0.0f;



void init()
{
    glClearColor(
        0.85f,
        0.85f,
        0.87f,
        1.0f
    );

    glMatrixMode(GL_PROJECTION);

    glLoadIdentity();

    gluOrtho2D(
        0,
        100,
        0,
        75
    );
}



void drawCircle(
    float cx,
    float cy,
    float r,
    int segments
)
{
    glBegin(GL_POLYGON);

    for (int i = 0; i < segments; i++)
    {
        float angle =
            2.0f * PI * i / segments;

        float x =
            r * cosf(angle);

        float y =
            r * sinf(angle);

        glVertex2f(
            cx + x,
            cy + y
        );
    }

    glEnd();
}



void drawArc(
    float cx,
    float cy,
    float r,
    float startAngle,
    float endAngle,
    int segments
)
{
    glBegin(GL_LINE_STRIP);

    for (int i = 0; i <= segments; i++)
    {
        float angle =
            startAngle +
            (endAngle - startAngle) *
            i / segments;

        float x =
            r * cosf(angle);

        float y =
            r * sinf(angle);

        glVertex2f(
            cx + x,
            cy + y
        );
    }

    glEnd();
}


// SKY

void drawSky()
{
    glColor3f(
        0.45f,
        0.68f,
        0.92f
    );

    glBegin(GL_QUADS);

    glVertex2f(0, 40);
    glVertex2f(100, 40);
    glVertex2f(100, 75);
    glVertex2f(0, 75);

    glEnd();


    glColor3f(
        0.98f,
        0.98f,
        1.0f
    );


    drawCircle(12.0f, 66.0f, 2.2f, 20);
    drawCircle(15.5f, 67.5f, 2.8f, 20);
    drawCircle(19.5f, 66.2f, 2.2f, 20);
    drawCircle(16.0f, 64.8f, 2.4f, 20);


    drawCircle(45.0f, 71.0f, 1.8f, 20);
    drawCircle(48.0f, 72.2f, 2.3f, 20);
    drawCircle(51.5f, 71.0f, 1.8f, 20);
    drawCircle(48.2f, 70.0f, 2.0f, 20);


    drawCircle(60.0f, 63.0f, 1.5f, 20);
    drawCircle(62.5f, 63.8f, 1.9f, 20);
    drawCircle(65.0f, 63.0f, 1.5f, 20);
}



void drawDome()
{
    float cx = 77.0f;
    float cy = 52.0f;
    float radius = 22.0f;


    glColor3f(
        0.80f,
        0.82f,
        0.85f
    );

    drawCircle(
        cx,
        cy,
        radius,
        100
    );


    glColor3f(
        0.20f,
        0.25f,
        0.28f
    );


    for (
        float offset = -15.0f;
        offset <= 15.0f;
        offset += 6.0f
    )
    {
        glBegin(GL_QUADS);

        float a =
            sqrt(
                radius * radius -
                offset * offset
            );

        float b =
            sqrt(
                radius * radius -
                (offset + 2.5f) *
                (offset + 2.5f)
            );


        glVertex2f(
            cx - a,
            cy + offset
        );

        glVertex2f(
            cx + a,
            cy + offset
        );

        glVertex2f(
            cx + b,
            cy + offset + 2.5f
        );

        glVertex2f(
            cx - b,
            cy + offset + 2.5f
        );

        glEnd();
    }
}



void drawFloodLight()
{
    glColor3f(
        0.6f,
        0.6f,
        0.6f
    );

    glLineWidth(3.0f);

    glBegin(GL_LINES);

    glVertex2f(8.0f, 32.0f);
    glVertex2f(8.0f, 58.0f);

    glEnd();


    glColor3f(
        0.3f,
        0.3f,
        0.3f
    );

    glBegin(GL_QUADS);

    glVertex2f(4.0f, 58.0f);
    glVertex2f(12.0f, 58.0f);
    glVertex2f(12.0f, 65.0f);
    glVertex2f(4.0f, 65.0f);

    glEnd();


    glColor3f(
        1.0f,
        1.0f,
        0.9f
    );

    for (
        float x = 5.0f;
        x <= 11.0f;
        x += 1.5f
    )
    {
        for (
            float y = 59.0f;
            y <= 64.0f;
            y += 2.0f
        )
        {
            drawCircle(
                x,
                y,
                0.5f,
                10
            );
        }
    }
}



void drawWallAndFlags()
{
    glColor3f(
        0.12f,
        0.28f,
        0.16f
    );

    glBegin(GL_QUADS);

    glVertex2f(0, 34);
    glVertex2f(100, 34);
    glVertex2f(100, 39);
    glVertex2f(0, 39);

    glEnd();


    glColor3f(
        0.5f,
        0.15f,
        0.15f
    );

    glBegin(GL_QUADS);

    glVertex2f(0, 39);
    glVertex2f(100, 39);
    glVertex2f(100, 40);
    glVertex2f(0, 40);

    glEnd();


    glColor3f(
        0.02f,
        0.02f,
        0.02f
    );

    float startX = 2.0f;

    for (int i = 0; i < 15; i++)
    {
        glBegin(GL_QUADS);

        glVertex2f(
            startX,
            35.0f
        );

        glVertex2f(
            startX + 3.5f,
            35.0f
        );

        glVertex2f(
            startX + 3.5f,
            38.5f
        );

        glVertex2f(
            startX,
            38.5f
        );

        glEnd();

        startX += 6.5f;
    }
}



void drawHeader()
{
    glColor3f(
        0.7f,
        0.7f,
        0.72f
    );

    glBegin(GL_QUADS);

    glVertex2f(36.0f, 39.0f);
    glVertex2f(64.0f, 39.0f);
    glVertex2f(64.0f, 48.0f);
    glVertex2f(36.0f, 48.0f);

    glEnd();


    glColor3f(
        0.2f,
        0.2f,
        0.25f
    );

    glBegin(GL_QUADS);

    glVertex2f(37.0f, 44.0f);
    glVertex2f(63.0f, 44.0f);
    glVertex2f(63.0f, 47.0f);
    glVertex2f(37.0f, 47.0f);

    glEnd();


    glColor3f(
        1.0f,
        1.0f,
        1.0f
    );

    glRasterPos2f(
        46.0f,
        45.0f
    );

    const char* title = "AIUB";

    for (
        const char* c = title;
        *c != '\0';
        c++
    )
    {
        glutBitmapCharacter(
            GLUT_BITMAP_HELVETICA_18,
            *c
        );
    }
}



void drawField()
{
    glColor3f(
        0.22f,
        0.55f,
        0.08f
    );

    glBegin(GL_QUADS);

    glVertex2f(0, 0);
    glVertex2f(100, 0);
    glVertex2f(100, 34);
    glVertex2f(0, 34);

    glEnd();


    glColor3f(
        1.0f,
        1.0f,
        1.0f
    );

    glLineWidth(2.0f);


    glBegin(GL_LINE_STRIP);

    glVertex2f(44.0f, 34.0f);
    glVertex2f(44.0f, 31.0f);
    glVertex2f(56.0f, 31.0f);
    glVertex2f(56.0f, 34.0f);

    glEnd();


    glBegin(GL_LINE_LOOP);

    glVertex2f(40.0f, 28.0f);
    glVertex2f(60.0f, 28.0f);
    glVertex2f(75.0f, 15.0f);
    glVertex2f(25.0f, 15.0f);

    glEnd();


    drawCircle(
        50.0f,
        20.0f,
        0.5f,
        12
    );


    drawArc(
        50.0f,
        20.0f,
        7.0f,
        3.936f,
        5.487f,
        24
    );
}



void drawGoalPost()
{
    float lx = 40.0f;
    float rx = 60.0f;

    float groundY = 28.0f;
    float barY = 38.0f;

    float postThick = 0.6f;


    glColor3f(
        0.95f,
        0.95f,
        0.95f
    );


    glBegin(GL_QUADS);

    glVertex2f(
        lx - postThick,
        groundY
    );

    glVertex2f(
        lx + postThick,
        groundY
    );

    glVertex2f(
        lx + postThick,
        barY
    );

    glVertex2f(
        lx - postThick,
        barY
    );

    glEnd();


    glBegin(GL_QUADS);

    glVertex2f(
        rx - postThick,
        groundY
    );

    glVertex2f(
        rx + postThick,
        groundY
    );

    glVertex2f(
        rx + postThick,
        barY
    );

    glVertex2f(
        rx - postThick,
        barY
    );

    glEnd();


    glBegin(GL_QUADS);

    glVertex2f(
        lx - postThick,
        barY - postThick
    );

    glVertex2f(
        rx + postThick,
        barY - postThick
    );

    glVertex2f(
        rx + postThick,
        barY + postThick
    );

    glVertex2f(
        lx - postThick,
        barY + postThick
    );

    glEnd();


    glColor3f(
        0.85f,
        0.85f,
        0.85f
    );

    glLineWidth(1.0f);


    for (
        float x = lx;
        x <= rx;
        x += 2.0f
    )
    {
        glBegin(GL_LINES);

        glVertex2f(
            x,
            groundY
        );

        glVertex2f(
            x,
            barY
        );

        glEnd();
    }


    for (
        float y = groundY;
        y <= barY;
        y += 1.5f
    )
    {
        glBegin(GL_LINES);

        glVertex2f(
            lx,
            y
        );

        glVertex2f(
            rx,
            y
        );

        glEnd();
    }
}



void drawKeeper()
{
    float gy = gkX;

    float gf = 27.0f;


    glColor3f(
        0.05f,
        0.05f,
        0.05f
    );

    glBegin(GL_QUADS);

    glVertex2f(
        gy - 1.3f,
        gf
    );

    glVertex2f(
        gy - 0.4f,
        gf
    );

    glVertex2f(
        gy - 0.4f,
        gf + 1.0f
    );

    glVertex2f(
        gy - 1.3f,
        gf + 1.0f
    );

    glEnd();


    glBegin(GL_QUADS);

    glVertex2f(
        gy + 0.4f,
        gf
    );

    glVertex2f(
        gy + 1.3f,
        gf
    );

    glVertex2f(
        gy + 1.3f,
        gf + 1.0f
    );

    glVertex2f(
        gy + 0.4f,
        gf + 1.0f
    );

    glEnd();


    glColor3f(
        0.75f,
        0.55f,
        0.4f
    );

    glBegin(GL_QUADS);

    glVertex2f(
        gy - 1.2f,
        gf + 1.0f
    );

    glVertex2f(
        gy - 0.4f,
        gf + 1.0f
    );

    glVertex2f(
        gy - 0.4f,
        gf + 3.5f
    );

    glVertex2f(
        gy - 1.2f,
        gf + 3.5f
    );

    glEnd();


    glBegin(GL_QUADS);

    glVertex2f(
        gy + 0.4f,
        gf + 1.0f
    );

    glVertex2f(
        gy + 1.2f,
        gf + 1.0f
    );

    glVertex2f(
        gy + 1.2f,
        gf + 3.5f
    );

    glVertex2f(
        gy + 0.4f,
        gf + 3.5f
    );

    glEnd();


    glColor3f(
        1.0f,
        1.0f,
        1.0f
    );

    glBegin(GL_QUADS);

    glVertex2f(
        gy - 1.5f,
        gf + 3.5f
    );

    glVertex2f(
        gy + 1.5f,
        gf + 3.5f
    );

    glVertex2f(
        gy + 1.5f,
        gf + 5.0f
    );

    glVertex2f(
        gy - 1.5f,
        gf + 5.0f
    );

    glEnd();


    glColor3f(
        0.95f,
        0.85f,
        0.1f
    );

    glBegin(GL_QUADS);

    glVertex2f(
        gy - 1.5f,
        gf + 5.0f
    );

    glVertex2f(
        gy + 1.5f,
        gf + 5.0f
    );

    glVertex2f(
        gy + 1.5f,
        gf + 10.0f
    );

    glVertex2f(
        gy - 1.5f,
        gf + 10.0f
    );

    glEnd();


    glColor3f(
        0.95f,
        0.85f,
        0.1f
    );


    glBegin(GL_QUADS);

    glVertex2f(
        gy - 2.6f,
        gf + 6.0f
    );

    glVertex2f(
        gy - 1.5f,
        gf + 6.0f
    );

    glVertex2f(
        gy - 1.5f,
        gf + 10.0f
    );

    glVertex2f(
        gy - 2.6f,
        gf + 9.3f
    );

    glEnd();


    glBegin(GL_QUADS);

    glVertex2f(
        gy + 1.5f,
        gf + 6.0f
    );

    glVertex2f(
        gy + 2.6f,
        gf + 6.0f
    );

    glVertex2f(
        gy + 2.6f,
        gf + 9.3f
    );

    glVertex2f(
        gy + 1.5f,
        gf + 10.0f
    );

    glEnd();


    glColor3f(
        0.75f,
        0.55f,
        0.4f
    );

    drawCircle(
        gy - 2.4f,
        gf + 9.6f,
        0.5f,
        10
    );

    drawCircle(
        gy + 2.4f,
        gf + 9.6f,
        0.5f,
        10
    );


    glColor3f(
        0.2f,
        0.15f,
        0.1f
    );

    drawCircle(
        gy,
        gf + 11.0f,
        1.0f,
        20
    );
}



void drawStriker()
{
    float sx = 45.0f;
    float footY = 9.0f;


    glColor3f(
        0.05f,
        0.05f,
        0.05f
    );

    glBegin(GL_QUADS);

    glVertex2f(
        sx - 2.3f,
        footY
    );

    glVertex2f(
        sx - 1.4f,
        footY
    );

    glVertex2f(
        sx - 1.4f,
        footY + 1.0f
    );

    glVertex2f(
        sx - 2.3f,
        footY + 1.0f
    );

    glEnd();


    glBegin(GL_QUADS);

    glVertex2f(
        sx + 1.4f,
        footY
    );

    glVertex2f(
        sx + 2.3f,
        footY
    );

    glVertex2f(
        sx + 2.3f,
        footY + 1.0f
    );

    glVertex2f(
        sx + 1.4f,
        footY + 1.0f
    );

    glEnd();


    glColor3f(
        0.75f,
        0.55f,
        0.4f
    );

    glBegin(GL_QUADS);

    glVertex2f(
        sx - 2.2f,
        footY + 1.0f
    );

    glVertex2f(
        sx - 1.2f,
        footY + 1.0f
    );

    glVertex2f(
        sx - 1.2f,
        footY + 4.0f
    );

    glVertex2f(
        sx - 2.2f,
        footY + 4.0f
    );

    glEnd();


    glBegin(GL_QUADS);

    glVertex2f(
        sx + 1.2f,
        footY + 1.0f
    );

    glVertex2f(
        sx + 2.2f,
        footY + 1.0f
    );

    glVertex2f(
        sx + 2.2f,
        footY + 4.0f
    );

    glVertex2f(
        sx + 1.2f,
        footY + 4.0f
    );

    glEnd();


    glColor3f(
        1.0f,
        1.0f,
        1.0f
    );

    glBegin(GL_QUADS);

    glVertex2f(
        sx - 2.5f,
        footY + 4.0f
    );

    glVertex2f(
        sx + 2.5f,
        footY + 4.0f
    );

    glVertex2f(
        sx + 2.5f,
        footY + 7.0f
    );

    glVertex2f(
        sx - 2.5f,
        footY + 7.0f
    );

    glEnd();


    glColor3f(
        0.1f,
        0.3f,
        0.8f
    );

    glBegin(GL_QUADS);

    glVertex2f(
        sx - 2.5f,
        footY + 7.0f
    );

    glVertex2f(
        sx + 2.5f,
        footY + 7.0f
    );

    glVertex2f(
        sx + 2.5f,
        footY + 14.0f
    );

    glVertex2f(
        sx - 2.5f,
        footY + 14.0f
    );

    glEnd();


    glColor3f(
        0.1f,
        0.3f,
        0.8f
    );


    glBegin(GL_QUADS);

    glVertex2f(
        sx - 4.2f,
        footY + 7.5f
    );

    glVertex2f(
        sx - 2.5f,
        footY + 7.5f
    );

    glVertex2f(
        sx - 2.5f,
        footY + 13.5f
    );

    glVertex2f(
        sx - 4.2f,
        footY + 10.5f
    );

    glEnd();


    glBegin(GL_QUADS);

    glVertex2f(
        sx + 2.5f,
        footY + 7.5f
    );

    glVertex2f(
        sx + 4.2f,
        footY + 7.5f
    );

    glVertex2f(
        sx + 4.2f,
        footY + 10.5f
    );

    glVertex2f(
        sx + 2.5f,
        footY + 13.5f
    );

    glEnd();


    glColor3f(
        0.75f,
        0.55f,
        0.4f
    );

    drawCircle(
        sx - 4.0f,
        footY + 10.0f,
        0.6f,
        10
    );

    drawCircle(
        sx + 4.0f,
        footY + 10.0f,
        0.6f,
        10
    );


    glColor3f(
        0.15f,
        0.1f,
        0.05f
    );

    drawCircle(
        sx,
        footY + 15.4f,
        1.4f,
        20
    );
}



void drawBall()
{
    glColor3f(
        1.0f,
        1.0f,
        1.0f
    );

    drawCircle(
        ballX,
        ballY,
        1.2f,
        20
    );


    glColor3f(
        0.0f,
        0.0f,
        0.0f
    );

    drawCircle(
        ballX,
        ballY,
        0.5f,
        6
    );
}



void drawResultText()
{
    if (!goalScored &&
        !saved &&
        !notGoal)
    {
        return;
    }


    const char* msg;


    if (goalScored)
    {
        msg = "GOAL!";
    }
    else if (saved)
    {
        msg = "SAVED!";
    }
    else
    {
        msg = "NOT GOAL!";
    }


    if (goalScored)
    {
        glColor3f(
            0.05f,
            0.75f,
            0.1f
        );
    }
    else if (saved)
    {
        glColor3f(
            0.85f,
            0.1f,
            0.1f
        );
    }
    else
    {
        glColor3f(
            0.9f,
            0.5f,
            0.05f
        );
    }


    float pop =
        resetCounter / 10.0f;

    if (pop > 1.0f)
    {
        pop = 1.0f;
    }


    float scale =
        0.018f *
        (0.4f + 0.6f * pop);


    float textWidth = 0.0f;

    for (
        const char* c = msg;
        *c != '\0';
        c++
    )
    {
        textWidth +=
            (float)glutStrokeWidth(
                GLUT_STROKE_ROMAN,
                *c
            );
    }


    glPushMatrix();

    glTranslatef(
        50.0f,
        55.0f,
        0.0f
    );

    glScalef(
        scale,
        scale,
        1.0f
    );

    glTranslatef(
        -textWidth / 2.0f,
        0.0f,
        0.0f
    );


    glLineWidth(4.0f);


    for (
        const char* c = msg;
        *c != '\0';
        c++
    )
    {
        glutStrokeCharacter(
            GLUT_STROKE_ROMAN,
            *c
        );
    }


    glPopMatrix();

    glLineWidth(2.0f);
}



void playGoalSound()
{
#ifdef _WIN32

    Beep(700, 120);
    Beep(900, 120);
    Beep(1200, 250);

#else

    printf("\a");
    fflush(stdout);

#endif
}



void drawWantToPlayBubble()
{
    glColor3f(1.0f, 1.0f, 1.0f);

    drawCircle(45.5f, 30.5f, 0.35f, 20);
    drawCircle(46.4f, 32.0f, 0.55f, 20);
    drawCircle(47.4f, 33.4f, 0.75f, 20);

    drawCircle(42.0f, 40.0f, 5.5f, 30);
    drawCircle(47.0f, 42.5f, 6.5f, 30);
    drawCircle(53.5f, 43.0f, 7.0f, 30);
    drawCircle(60.0f, 41.5f, 6.2f, 30);
    drawCircle(63.5f, 38.5f, 5.0f, 30);
    drawCircle(58.0f, 37.0f, 6.0f, 30);
    drawCircle(48.0f, 36.5f, 5.2f, 30);

    glColor3f(0.1f, 0.2f, 0.5f);

    glRasterPos2f(38.0f, 42.0f);
    const char* line1 = "I want to play";
    for (const char* c = line1; *c != '\0'; c++)
        glutBitmapCharacter(GLUT_BITMAP_HELVETICA_18, *c);

    glRasterPos2f(43.0f, 38.0f);
    const char* line2 = "football!";
    for (const char* c = line2; *c != '\0'; c++)
        glutBitmapCharacter(GLUT_BITMAP_HELVETICA_18, *c);
}



void drawMatch()
{
    drawSky();
    drawDome();
    drawFloodLight();
    drawWallAndFlags();
    drawHeader();
    drawField();
    drawGoalPost();
    drawKeeper();
    drawStriker();
    drawBall();
    drawResultText();
}


// KEYBOARD

void keyboard(
    unsigned char key,
    int x,
    int y
)
{
    if (introPhase != 2)
    {
        return;
    }


    if (key == 'a' || key == 'A')
    {
        shotMode = 1;
        ballTargetX = leftX;
        glutPostRedisplay();
        return;
    }



    if (key == 'b' || key == 'B')
    {
        shotMode = 2;
        ballTargetX = rightX;
        glutPostRedisplay();
        return;
    }



    if (key == 'x' || key == 'X')
    {
        if (shotMode == 1)
        {
            ballTargetX = leftX;
        }
        else if (shotMode == 2)
        {
            ballTargetX = rightX;
        }
        else
        {
            ballTargetX = centerX;
        }

        ballInFlight = true;
        goalScored = false;
        saved = false;
        notGoal = false;
        t = 0.0f;
        resetCounter = 0;

        ballX = ballStartX;
        ballY = ballStartY;

        gkX = gkDefaultX;
    }


    else if (key == 'y' || key == 'Y')
    {
        if (ballInFlight && !saved && !goalScored && !notGoal)
        {
            gkX = ballTargetX;

            if (t < 0.88f)
            {
                saved = true;
                ballInFlight = false;

                ballX = gkX;
                ballY = ballTargetY - 1.5f;

                resetCounter = 0;
            }
        }
    }

    glutPostRedisplay();
}



void timer(int value)
{

    if (introPhase == 0)
    {
        bubbleGrow += 0.01f;

        if (bubbleGrow > 1.0f)
        {
            bubbleGrow = 1.0f;
        }

        introTimer += 1.0f;

        if (introTimer > 90.0f)
        {
            introPhase = 2;

            ballX = ballStartX;
            ballY = ballStartY;
            gkX = gkDefaultX;
            shotMode = 0;
            ballTargetX = centerX;
        }

        glutPostRedisplay();
        return;
    }




    if (ballInFlight)
    {
        t += 0.010f;


        if (t >= 1.0f)
        {
            t = 1.0f;
            ballInFlight = false;


            if (shotMode == 1 || shotMode == 2)
            {
                goalScored = true;
                saved = false;
                notGoal = false;
                resetCounter = 0;

                playGoalSound();
            }


            else
            {
                notGoal = true;
                goalScored = false;
                saved = false;
                resetCounter = 0;
            }
        }


        float dir;

        if (ballTargetX >= ballStartX)
        {
            dir = 1.0f;
        }
        else
        {
            dir = -1.0f;
        }

        float ctrlX = ballTargetX + dir * 4.0f;
        float ctrlY = ballStartY + 5.0f;
        float u = 1.0f - t;

        ballX = u * u * ballStartX + 2.0f * u * t * ctrlX + t * t * ballTargetX;
        ballY = u * u * ballStartY + 2.0f * u * t * ctrlY + t * t * ballTargetY;
    }


    else if (goalScored || saved || notGoal)
    {
        resetCounter++;

        if (resetCounter > 90)
        {
            goalScored = false;
            saved = false;
            notGoal = false;

            ballX = ballStartX;
            ballY = ballStartY;

            gkX = gkDefaultX;

            shotMode = 0;
            ballTargetX = centerX;

            resetCounter = 0;
        }
    }

    glutPostRedisplay();
}



void display8()
{
    glClear(GL_COLOR_BUFFER_BIT);


    if (introPhase == 0)
    {
        glColor3f(0.85f, 0.85f, 0.87f);

        glBegin(GL_QUADS);
        glVertex2f(0, 0);
        glVertex2f(100, 0);
        glVertex2f(100, 75);
        glVertex2f(0, 75);
        glEnd();

        glPushMatrix();

        float pivotX = 52.0f;
        float pivotY = 38.0f;

        glTranslatef(pivotX, pivotY, 0);
        glScalef(bubbleGrow, bubbleGrow, 1.0f);
        glTranslatef(-pivotX, -pivotY, 0);

        drawWantToPlayBubble();

        glPopMatrix();
    }


    else
    {
        drawMatch();
    }

    glFlush();
}



} // namespace Football

void displayMain()
{
    if (scene == 1)
        Entrance::display00();
    else if (scene == 2)
        Entrance::display01();
    else if (scene == 3)
        Corridor::display1();
    else if (scene == 4)
        Corridor::display2();
    else if (scene == 5)
        Classroom::display3();
    else if (scene == 6)
        Classroom::display4();
    else if (scene == 7)
        Classroom::display5();
    else if (scene == 8)
        Teacher::display7();
    else if (scene == 9)
        Classroom::display61();
    else if (scene == 10)
        Football::display8();
}


void keyboardMain(unsigned char key, int x, int y)
{
    if (key == 27)
    {
        exit(0);
    }

    if (key == 'n' || key == 'N')
    {
        if (scene == 1)
        {
            Entrance::keyboard(key, x, y);

            if (Entrance::scene == 1)
            {
                scene = 2;
            }
        }
        else if (scene == 2)
        {
            if (Entrance::student1Y >= 19.0f &&
                !Entrance::entering &&
                !Entrance::doorOpening)
            {
                scene = 3;
            }
        }
        else if (scene == 4 && waitingForNext)
        {
            waitingForNext = false;
            scene = 5;

            Classroom::phase = 1;
            Classroom::moving = false;
        }
        else if (scene == 7 && waitingForNext)
        {
            waitingForNext = false;
            scene = 8;

            Teacher::teacherX = Teacher::TEACHER_CENTER_X;
        }
        else if (scene == 8)
        {
            scene = 9;

            Classroom::phase = 4;
            Classroom::cloudY = 0.0f;
            Classroom::humanScale = 1.0f;
            Classroom::dreamStarted = false;
        }
        else if (scene == 9)
        {
            scene = 10;
        }

        glutPostRedisplay();
        return;
    }

    if (scene == 1 || scene == 2)
    {
        Entrance::keyboard(key, x, y);
    }
    else if (scene == 3 || scene == 4)
    {
        Corridor::keyboard(key, x, y);
    }
    else if (scene == 5 || scene == 6 || scene == 7 || scene == 9)
    {
        Classroom::keyboard(key, x, y);
    }
    else if (scene == 8)
    {
        Teacher::keyboard(key, x, y);
    }
    else if (scene == 10)
    {
        Football::keyboard(key, x, y);
    }

    glutPostRedisplay();
}


// MASTER TIMER
void timerMain(int value)
{
    static int teacherTick = 0;

    if (scene == 1 || scene == 2)
    {
        Entrance::timer(0);
    }
    else if (scene == 3)
    {
        Corridor::timer(0);

        if (Corridor::phase == 2)
        {
            scene = 4;
            waitingForNext = false;
        }
    }
    else if (scene == 4)
    {
        Corridor::timer(0);

        if (!Corridor::walking2 && !Corridor::human2Visible)
        {
            waitingForNext = true;
        }
    }
    else if (scene == 5)
    {
        Classroom::timer(0);

        if (Classroom::phase == 2)
        {
            scene = 6;
            Classroom::standTimer = 0.0f;
        }
    }
    else if (scene == 6)
    {
        Classroom::timer(0);

        if (Classroom::phase == 3)
        {
            scene = 7;
            Classroom::sitProgress = 0.0f;
        }
    }
    else if (scene == 7)
    {
        Classroom::timer(0);

        if (Classroom::sitProgress >= 1.0f)
        {
            Classroom::sitProgress = 1.0f;
            Classroom::eyeMoveX = 0.0f;
            Classroom::cloudY = 0.0f;
            Classroom::humanScale = 1.0f;
            Classroom::dreamStarted = false;
            waitingForNext = true;
        }
    }
    else if (scene == 8)
    {
        teacherTick++;

        if (teacherTick >= 2)
        {
            Teacher::timer(0);
            teacherTick = 0;
        }
    }
    else if (scene == 9)
    {
        Classroom::timer(0);
    }
    else if (scene == 10)
    {
        Football::timer(0);
    }

    glutPostRedisplay();
    glutTimerFunc(30, timerMain, 0);
}



// MAIN
int main(int argc, char** argv)
{
    srand((unsigned int)time(0));

    glutInit(&argc, argv);

    glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB);

    glutInitWindowSize(1000, 750);
    glutInitWindowPosition(100, 50);

    glutCreateWindow("Complete OpenGL Project");

    // All programs use the same 0..100 and 0..75 coordinate system.
    Entrance::init();
    Corridor::init();

    glutDisplayFunc(displayMain);
    glutKeyboardFunc(keyboardMain);
    glutTimerFunc(30, timerMain, 0);

    glutMainLoop();

    return 0;
}
